// Единый цикл requestAnimationFrame: фиксированный шаг логики + отдельная отрисовка.
// Здесь же правила «как в Dark Souls» (костры, смерть, души, респавн, сохранение) и лавка торговца.
// Режимы: play — игра, shop — окно торговца, dead — экран смерти.
(function () {
  const DF = window.DF, C = DF.CONFIG, PRESS = ['jump', 'light', 'heavy', 'special', 'roll', 'heal'];
  class Game {
    constructor(canvas) {
      this.input = new DF.Input(); this.renderer = new DF.Renderer(canvas); this.camera = new DF.Camera();
      this.world = DF.World.createTestRoom(); this.animator = new DF.Animator(); this.vfx = new DF.Effects();
      const sv = DF.Save.load() || {};
      this.bonfireId = sv.bonfire || null; this.lit = new Set(sv.lit || []); this.souls = sv.souls || 0; this.bloodstain = sv.blood || null;
      this.owned = new Set(sv.weapons || ['wood']); this.weapon = this.owned.has(sv.weapon) ? sv.weapon : 'wood';
      const sp = this.spawnPoint(); this.player = new DF.Player(sp.x, sp.y);
      this.enemies = []; this.spawnEnemies();
      this.mode = 'play'; this.deadT = 0; this.fade = 1; this.banner = { text: '', t: 0 }; this.shake = 0; this.hitstop = 0; this.time = 0;
      this.shop = { sel: 0, line: '', msg: '' }; this.trader = { t: 0, approveT: 0 }; this.wasSafe = false;
      this.fx = []; this.parts = []; this.queue = {};
      this.debug = false; this.fps = 0; this.acc = 0; this.last = 0; this._fpsT = 0; this._fpsN = 0;
      this.camera.snap(this.player, this.world);
      this.loop = t => {
        const dt = Math.min((t - this.last) / 1000, 0.1); this.last = t;
        this.update(dt); this.renderer.draw(this);
        this._fpsT += dt; this._fpsN++;
        if (this._fpsT >= 0.5) { this.fps = Math.round(this._fpsN / this._fpsT); this._fpsT = 0; this._fpsN = 0; }
        requestAnimationFrame(this.loop);
      };
    }
    start() { requestAnimationFrame(t => { this.last = t; this.loop(t); }); }
    spawnPoint() {
      const b = this.world.bonfires.find(x => x.id === this.bonfireId);
      return b ? { x: b.x - C.PLAYER.W / 2, y: b.y - C.PLAYER.H } : { x: this.world.spawn.x, y: this.world.spawn.y };
    }
    spawnEnemies() { this.enemies = this.world.spawns.map(s => new DF.Enemy(s.type, s.x, s.y)); }
    nearBonfire() {
      const p = this.player;
      return this.world.bonfires.find(b => Math.abs(p.x + p.w / 2 - b.x) < 40 && Math.abs(p.y + p.h - b.y) < 24) || null;
    }
    nearNpc() {
      const p = this.player;
      return this.world.npcs.find(n => Math.abs(p.x + p.w / 2 - n.x) < 60 && Math.abs(p.y + p.h - n.y) < 24) || null;
    }
    persist() { DF.Save.write({ bonfire: this.bonfireId, lit: [...this.lit], souls: this.souls, blood: this.bloodstain, weapons: [...this.owned], weapon: this.weapon }); }
    say(text, t) { this.banner = { text, t: t || 2.2 }; }
    rest(b) {
      const first = !this.lit.has(b.id); this.lit.add(b.id); this.bonfireId = b.id;
      const p = this.player; p.hp = p.maxHp; p.sta = p.maxSta; p.estus = p.estusMax;
      this.spawnEnemies(); this.fade = 1; this.say(first ? 'КОСТЁР ЗАЖЖЁН' : b.name); this.persist();
    }
    addFx(x, y, text, color) { this.fx.push({ x, y, text, color, t: 1.0 }); }
    sparks(x, y, color, n) { for (let i = 0; i < n; i++) this.parts.push({ x, y, vx: (Math.random() - 0.5) * 260, vy: -Math.random() * 220, t: 0.35, color }); }
    onEnemyHit(e, def, dir, result) {
      this.addFx(e.x + e.w / 2, e.y - 10, String(def.damage), '#fff');
      this.sparks(e.x + e.w / 2, e.y + e.h / 2, '#ffd9a0', 6);
      this.hitstop = result === 'kill' ? 0.1 : 0.05; this.shake = Math.max(this.shake, def.kind === 'heavy' ? 7 : 3);
      if (result === 'kill') { this.souls += e.d.souls; this.addFx(e.x + e.w / 2, e.y - 28, `+${e.d.souls}`, '#e8d9a8'); this.persist(); }
    }
    onPlayerHit(e) {
      const p = this.player; this.sparks(p.x + p.w / 2, p.y + p.h / 2, '#c33', 8); this.hitstop = 0.07; this.shake = 8;
      this.addFx(p.x + p.w / 2, p.y - 10, String(e.d.dmg), '#ff6060');
    }
    // Росчерк привязан к атакующему спрайту: позиция следует за рыцарем, а угол меняется по ходу взмаха.
    spawnSlash() {
      const p = this.player, a = p.atk;
      if (p.state !== 'attack' || !a || a.phase !== 'active' || a.vfx) return;
      a.vfx = true;
      const v = DF.DATA.WEAPONS[this.weapon].vfx;
      const anim = a.def.anim;
      const key = a.act === 'light' ? (a.idx === 2 ? v.finish : v.light)
        : a.act === 'heavy' ? v.heavy : v.special;

      // У каждой анимации — своя дуга. Угол следует за движением клинка: горизонтальный первый удар,
      // диагональный выпад/комбо и более широкий нисходящий замах тяжёлой атаки.
      const profiles = {
        attack3:  { x0: 48, x1: 62, y0:  1, y1:  4, r0: -0.22, r1:  0.12, life: 0.13, scale: 0.92 },
        runattack:{ x0: 50, x1: 64, y0:  0, y1:  6, r0: -0.08, r1:  0.34, life: 0.14, scale: 0.96 },
        attack2:  { x0: 48, x1: 58, y0:  0, y1:  7, r0:  0.34, r1:  0.78, life: 0.16, scale: 1.00 },
        attack1:  { x0: 47, x1: 59, y0: -3, y1:  7, r0:  0.48, r1:  0.92, life: 0.18, scale: 1.06 },
        defend:   { x0: 34, x1: 43, y0:  1, y1:  3, r0: -0.12, r1:  0.16, life: 0.12, scale: 0.70 }
      };
      const profile = profiles[anim] || profiles.attack3;
      const metalScale = this.weapon === 'steel' ? 0.57 : 0.47;
      const scale = metalScale * profile.scale * (a.act === 'heavy' ? 1.03 : 1);
      const y = p.y + (profile.y0 + profile.y1) * 0.5;
      const x = p.x + p.w / 2 + p.facing * (profile.x0 + profile.x1) * 0.5;
      this.vfx.spawn(key, x, y, {
        flip: p.facing,
        rot: profile.r0,
        rotStart: profile.r0,
        rotEnd: profile.r1,
        scale,
        scaleStart: scale * 0.82,
        scaleEnd: scale,
        alpha: v.alpha,
        duration: Math.min(profile.life, Math.max(0.11, a.def.active + 0.045)),
        follow: p,
        attack: a,
        offsetXStart: profile.x0,
        offsetXEnd: profile.x1,
        offsetYStart: profile.y0,
        offsetYEnd: profile.y1
      });
    }
    die() {
      const p = this.player, pos = p.y > this.world.pxH ? p.safe : { x: p.x, y: p.y };
      if (this.souls > 0) this.bloodstain = { x: pos.x + p.w / 2, y: pos.y + p.h, souls: this.souls };   // новое пятно заменяет старое
      this.souls = 0; this.mode = 'dead'; this.deadT = 0; this.shake = 10; this.persist();
    }
    respawn() {
      const sp = this.spawnPoint(); this.player.reset(sp); this.animator = new DF.Animator(); this.vfx = new DF.Effects();
      this.spawnEnemies(); this.mode = 'play'; this.fade = 1; this.camera.snap(this.player, this.world);
    }
    // --- лавка торговца
    openShop() { this.mode = 'shop'; this.player.vx = 0; this.shop = { sel: 0, msg: '', line: DF.DATA.TRADER.lines[Math.floor(Math.random() * DF.DATA.TRADER.lines.length)] }; }
    closeShop() { this.mode = 'play'; this.queue = {}; }
    buy(id) {
      const w = DF.DATA.WEAPONS[id], sh = this.shop;
      if (this.owned.has(id)) { this.weapon = id; sh.msg = `Экипировано: ${w.name}`; }
      else if (this.souls >= w.price) { this.souls -= w.price; this.owned.add(id); this.weapon = id; this.trader.approveT = 1.2; sh.msg = `Куплено: ${w.name}`; }
      else sh.msg = 'Не хватает душ';
      this.persist();
    }
    shopInput(i) {
      const ids = DF.DATA.SHOP, sh = this.shop;
      if (i.pressed('down')) sh.sel = (sh.sel + 1) % ids.length;
      if (i.pressed('jump')) sh.sel = (sh.sel + ids.length - 1) % ids.length;
      if (i.pressed('confirm')) this.buy(ids[sh.sel]);
      if (i.pressed('cancel') || i.pressed('interact')) this.closeShop();
    }
    update(dt) {
      const i = this.input;
      if (i.pressed('debug')) this.debug = !this.debug;
      if (i.pressed('wipe')) { DF.Save.clear(); location.reload(); return; }
      for (const a of PRESS) if (i.pressed(a)) this.queue[a] = true;
      let sim = dt; if (this.hitstop > 0) { this.hitstop -= dt; sim = 0; }
      const cmd = { left: i.down('left'), right: i.down('right'), down: i.down('down'), jumpHeld: i.down('jump'), jumpPressed: false, press: {} };
      const idle = { press: {} }, p = this.player;
      for (this.acc += sim; this.acc >= C.STEP; this.acc -= C.STEP) {
        if (this.mode === 'play') {
          cmd.jumpPressed = !!this.queue.jump; cmd.press = this.queue; this.queue = {};
          p.update(C.STEP, cmd, this.world); this.spawnSlash();
          for (const e of this.enemies) e.update(C.STEP, this.world, p);
          DF.Combat.update(this);
          if (p.hp <= 0) this.die();
        } else { this.queue = {}; p.update(C.STEP, idle, this.world); }
      }
      if (this.mode === 'play') {
        const nb = this.nearBonfire(), nn = this.nearNpc();
        if (i.pressed('interact') && p.state === 'move' && p.onGround) { if (nb) this.rest(nb); else if (nn) this.openShop(); }
        const bs = this.bloodstain;
        if (bs && Math.abs(p.x + p.w / 2 - bs.x) < 28 && Math.abs(p.y + p.h - bs.y) < 40) {
          this.souls += bs.souls; this.addFx(bs.x, bs.y - 30, `+${bs.souls}`, '#e8d9a8'); this.bloodstain = null; this.persist(); this.say('ДУШИ ВОЗВРАЩЕНЫ', 1.8);
        }
        const safe = p.x > this.world.safeX; if (safe && !this.wasSafe) this.say('БЕЗОПАСНАЯ ЗОНА', 2.6); this.wasSafe = safe;
        this.enemies = this.enemies.filter(e => !(e.dead && e.deadT > 1));
      } else if (this.mode === 'shop') this.shopInput(i);
      else { this.deadT += dt; if (this.deadT > 3.6) this.respawn(); }
      this.time += dt; this.trader.t += dt; this.trader.approveT = Math.max(0, this.trader.approveT - dt);
      this.fade = Math.max(0, this.fade - dt * 1.4); this.banner.t -= dt; this.shake = Math.max(0, this.shake - dt * 30);
      for (const f of this.fx) { f.y -= 28 * dt; f.t -= dt; } this.fx = this.fx.filter(f => f.t > 0);
      for (const q of this.parts) { q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 700 * dt; q.t -= dt; } this.parts = this.parts.filter(q => q.t > 0);
      this.vfx.update(sim); this.animator.update(sim, p); this.camera.update(dt, p, this.world); i.endFrame();
    }
  }
  DF.Game = Game;
})();
