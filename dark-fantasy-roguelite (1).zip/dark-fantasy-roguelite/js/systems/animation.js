// Выбор анимации игрока по его состоянию. Если загружены спрайт-листы — выбирает кадр (this.anim / this.frame),
// иначе считает процедурную «позу» для статичного запасного спрайта. Приземление и перекат — всегда процедурные.
(function () {
  const DF = window.DF, C = DF.CONFIG, P = C.PLAYER, A = C.ANIMS;
  class Animator {
    constructor() {
      this.t = 0; this.phase = 0; this.land = 0; this.landPower = 0; this.kick = 0; this.prevGround = true; this.prevVy = 0;
      this.anim = 'idle'; this.animT = 0; this.frame = 0; this.sheet = false;
      this.pose = { sx: 1, sy: 1, rot: 0, dy: 0, pivot: 0, alpha: 1 };
    }
    update(dt, p) {
      this.t += dt;
      if (p.onGround && !this.prevGround) { this.landPower = Math.min(1, this.prevVy / 800); this.land = 0.18; }
      if (!p.onGround && this.prevGround && p.vy < 0) this.kick = 0.12;
      this.prevGround = p.onGround; this.prevVy = p.vy;
      this.land = Math.max(0, this.land - dt); this.kick = Math.max(0, this.kick - dt);
      this.sheet = DF.Sprites.has(C.SPRITE.skin);
      this.procedural(dt, p);
      if (this.sheet) this.pick(dt, p);
    }
    pick(dt, p) {
      const S = DF.Sprites, o = this.pose, sp = Math.abs(p.vx); let name = 'idle', fr = 0;
      if (p.state === 'attack') name = p.atk.def.anim; else if (p.state === 'roll' || p.state === 'drink') name = 'protect';
      else if (p.state === 'hurt') name = 'hurt'; else if (p.state === 'dead') name = 'dead';
      else if (!p.onGround) name = 'jump'; else if (sp > 150) name = 'run'; else if (sp > 15) name = 'walk';
      if (name !== this.anim) { this.anim = name; this.animT = 0; }
      this.animT += dt;
      const a = A[name];
      if (p.state === 'attack') {
        const at = p.atk, d = at.def, k = at.phase === 'windup' ? at.t / d.windup : at.phase === 'active' ? at.t / d.active : at.t / d.recover;
        fr = S.attackFrame(a, at.phase, Math.min(1, k));
      } else if (name === 'hurt' || name === 'dead') fr = S.once(a, this.animT);
      else if (name === 'jump') fr = p.vy < -400 ? 0 : p.vy < -100 ? 1 : p.vy < 100 ? 2 : p.vy < 300 ? 3 : p.vy < 550 ? 4 : 5;
      else if (name === 'run') fr = S.loop(a, this.animT * Math.max(0.6, sp / P.SPEED));
      else if (name === 'walk') fr = S.loop(a, this.animT * Math.max(0.6, sp / 110));
      else if (name === 'idle') fr = S.loop(a, this.animT);
      this.frame = Math.min(a.frames - 1, fr);
      if (p.state !== 'roll') {                         // кадры уже содержат движение: оставляем только сжатие при приземлении
        o.rot = 0; o.dy = 0; o.pivot = 0; o.sx = 1; o.sy = 1;
        if (p.onGround && p.state === 'move' && this.land > 0) { const k = (this.land / 0.18) * (0.06 + 0.12 * this.landPower); o.sy = 1 - k; o.sx = 1 + k; }
      }
    }
    procedural(dt, p) {
      const o = this.pose, f = p.facing, speed = Math.min(1, Math.abs(p.vx) / P.SPEED);
      let sx = 1, sy = 1, rot = 0, dy = 0, pivot = 0;
      if (p.state === 'attack') {
        const a = p.atk, d = a.def, heavy = d.kind === 'heavy';
        if (a.phase === 'windup') { const k = a.t / d.windup; rot = -f * (heavy ? 0.4 : 0.2) * k; sy = 1 - 0.05 * k * (heavy ? 2 : 1); sx = 2 - sy; }
        else if (a.phase === 'active') { rot = f * (heavy ? 0.4 : 0.28); sx = 1.14; sy = 0.95; }
        else rot = f * 0.28 * (1 - a.t / d.recover);
      } else if (p.state === 'roll') { rot = f * (p.stateT / DF.DATA.ROLL.time) * Math.PI * 2; sy = 0.72; sx = 1.1; pivot = 0.3; }
      else if (p.state === 'hurt') { rot = -f * 0.22; sx = 0.94; sy = 1.04; }
      else if (p.state === 'drink') { rot = -f * 0.1; sy = 0.96; sx = 1.02; }
      else if (p.state === 'dead') rot = -f * Math.min(1.45, p.stateT * 6);
      else if (p.onGround) {
        if (speed > 0.05) { this.phase += Math.abs(p.vx) * dt * 0.05; dy = -Math.abs(Math.sin(this.phase)) * 3 * speed; rot = Math.sin(this.phase) * 0.025 + 0.1 * speed * f; sy = 1 + Math.sin(this.phase * 2) * 0.02 * speed; sx = 2 - sy; }
        else { this.phase = 0; sy = 1 + Math.sin(this.t * 2.4) * 0.012; sx = 2 - sy; }
        if (this.land > 0) { const k = (this.land / 0.18) * (0.08 + 0.18 * this.landPower); sy -= k; sx += k; }
      } else {
        const v = Math.max(-1, Math.min(1, p.vy / 700)); sy = 1 + (v < 0 ? -v * 0.12 : v * 0.06); sx = 2 - sy; rot = 0.08 * speed * f;
        if (this.kick > 0) { sy -= 0.05; sx += 0.05; }
      }
      o.sx = sx; o.sy = sy; o.rot = rot; o.dy = dy; o.pivot = pivot;
      o.alpha = p.state === 'roll' ? 0.65 : (p.invuln > 0 && p.state !== 'dead' && Math.floor(p.invuln * 25) % 2 ? 0.4 : 1);
    }
  }
  DF.Animator = Animator;
})();
