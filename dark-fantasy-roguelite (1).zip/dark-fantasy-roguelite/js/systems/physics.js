// Движение AABB-тела по тайловой карте. Подходит и игроку, и врагам: тело = {x,y,w,h,vx,vy,dropThrough}.
(function () {
  const DF = window.DF, T = DF.CONFIG.TILE;
  function bounds(b) {
    return [Math.floor(b.x / T), Math.floor((b.x + b.w - 0.001) / T),
            Math.floor(b.y / T), Math.floor((b.y + b.h - 0.001) / T)];
  }
  DF.Physics = {
    move(b, world, dt) {
      b.onGround = false;
      b.x += b.vx * dt;
      let [x0, x1, y0, y1] = bounds(b);
      for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
        if (world.get(tx, ty) !== 1) continue;
        if (b.vx > 0) b.x = tx * T - b.w; else if (b.vx < 0) b.x = (tx + 1) * T;
        b.vx = 0;
      }
      const prevBottom = b.y + b.h;
      b.y += b.vy * dt;
      [x0, x1, y0, y1] = bounds(b);
      for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
        const t = world.get(tx, ty);
        if (t === 1) {
          if (b.vy > 0) { b.y = ty * T - b.h; b.onGround = true; }
          else if (b.vy < 0) b.y = (ty + 1) * T;
          b.vy = 0;
        } else if (t === 2 && b.vy > 0 && !b.dropThrough && prevBottom <= ty * T + 0.01) {
          b.y = ty * T - b.h; b.vy = 0; b.onGround = true;
        }
      }
    }
  };
})();
