// Общая работа с горизонтальными спрайт-листами (кадры 128×128 подряд, ноги на нижней кромке).
// Используется и игроком, и врагами. Настройки кадров — DF.CONFIG.SPRITE / DF.CONFIG.ANIMS.
(function () {
  const DF = window.DF, C = DF.CONFIG;
  DF.Sprites = {
    has(skin) { return !!DF.Assets.get(skin + '_idle'); },
    loop(a, t) { return Math.floor(t * a.fps) % a.frames; },
    once(a, t) { return Math.min(a.frames - 1, Math.floor(t * a.fps)); },
    // Кадр атаки привязан к фазам боевой системы: замах → кадры до «удара», active → кадр удара, recover → остальные.
    attackFrame(a, phase, k) {
      const n = a.frames, h = Math.min(a.hit === undefined ? n - 1 : a.hit, n - 1);
      if (phase === 'windup') return h === 0 ? 0 : Math.min(h - 1, Math.floor(k * h));
      if (phase === 'active') return h;
      const rest = n - h - 1; return rest <= 0 ? h : h + 1 + Math.min(rest - 1, Math.floor(k * rest));
    },
    // o: {skin,key,frame,x,y(стопы),flip,scale,rot,sx,sy,pivot,alpha,filter, ax,ay — точка стоп в кадре (по умолчанию anchorX и низ кадра)}
    draw(c, o) {
      const img = DF.Assets.get(o.skin + '_' + o.key); if (!img) return false;
      const F = C.SPRITE.frame, ax = o.ax === undefined ? C.SPRITE.anchorX : o.ax, ay = o.ay === undefined ? F : o.ay, s = o.scale || 1, pv = (o.pivot || 0) * 64 * s;
      c.save(); c.globalAlpha = o.alpha === undefined ? 1 : o.alpha; if (o.filter) c.filter = o.filter;
      c.translate(Math.round(o.x), Math.round(o.y - pv)); c.rotate(o.rot || 0);
      c.scale((o.flip || 1) * (o.sx || 1) * s, (o.sy || 1) * s);
      c.drawImage(img, o.frame * F, 0, F, F, -ax, -ay + pv / s, F, F);
      c.restore(); return true;
    }
  };
})();
