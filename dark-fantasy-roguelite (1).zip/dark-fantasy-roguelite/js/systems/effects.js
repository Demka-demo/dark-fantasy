// Анимированные эффекты (росчерки мечей и т.п.): одноразовые, воспроизводятся один раз и удаляются.
// Листы: assets/effects/<ключ>.png (кадры 128×128 подряд), параметры — DF.CONFIG.VFX.
(function () {
  const DF = window.DF, C = DF.CONFIG;
  class Effects {
    constructor() { this.list = []; }
    spawn(key, x, y, o) {
      const spec = C.VFX[key]; if (!spec || !DF.Assets.get('vfx_' + key)) return;
      this.list.push({ key, spec, x, y, t: 0, flip: o.flip || 1, scale: o.scale || 1, alpha: o.alpha === undefined ? 1 : o.alpha });
    }
    update(dt) { for (const e of this.list) e.t += dt; this.list = this.list.filter(e => e.t * e.spec.fps < e.spec.frames); }
    draw(c) {
      for (const e of this.list) {
        const f = Math.min(e.spec.frames - 1, Math.floor(e.t * e.spec.fps));
        c.save(); c.globalAlpha = e.alpha; c.translate(Math.round(e.x), Math.round(e.y)); c.scale(e.flip * e.scale, e.scale);
        c.drawImage(DF.Assets.get('vfx_' + e.key), f * 128, 0, 128, 128, -64, -64, 128, 128); c.restore();
      }
    }
  }
  DF.Effects = Effects;
})();
