// Тайловая карта. Типы: 0 — пусто, 1 — сплошной, 2 — односторонняя платформа.
(function () {
  const DF = window.DF, T = DF.CONFIG.TILE;
  class World {
    constructor(w, h) {
      this.w = w; this.h = h; this.pxW = w * T; this.pxH = h * T;
      this.grid = Array.from({ length: h }, () => new Array(w).fill(0));
      this.spawn = { x: 3 * T, y: 0 };
    }
    get(tx, ty) {
      if (tx < 0 || tx >= this.w || ty < 0) return 1;
      if (ty >= this.h) return 0;
      return this.grid[ty][tx];
    }
    rect(x, y, w, h, t) {
      for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++)
        if (i >= 0 && i < this.w && j >= 0 && j < this.h) this.grid[j][i] = t;
    }
  }
  World.createTestRoom = function () {
    const W = 100, H = 24, w = new World(W, H);
    w.rect(0, 0, W, 1, 1); w.rect(0, 0, 1, H, 1); w.rect(W - 1, 0, 1, H, 1); w.rect(0, H - 2, W, 2, 1);
    for (let i = 0; i < 6; i++) w.rect(10 + i, H - 3 - i, 1, i + 1, 1);   // лестница
    w.rect(20, H - 5, 6, 1, 2); w.rect(28, H - 8, 6, 1, 2);              // деревянные платформы
    w.rect(36, H - 11, 6, 1, 2); w.rect(44, H - 8, 5, 1, 2);
    w.rect(52, H - 4, 6, 2, 1); w.rect(58, H - 6, 5, 1, 1);              // каменные блоки
    w.rect(66, H - 4, 4, 2, 1);
    const fy = (H - 2) * T;                                   // y поверхности пола
    w.spawn.y = fy - DF.CONFIG.PLAYER.H;
    w.bonfires = [{ id: 'ruins', name: 'Руины у входа', x: 4 * T + 16, y: fy }, { id: 'court', name: 'Разрушенный двор', x: 64 * T + 16, y: fy }, { id: 'haven', name: 'Тихая обитель', x: 82 * T + 16, y: fy }];
    w.safeX = 77 * T;                                          // туманные врата: враги дальше не проходят
    w.npcs = [{ type: 'trader', x: 90 * T, y: fy }];
    w.spawns = [['hollow', 18], ['wolf', 33], ['hollow', 40], ['wolf', 49], ['hollow', 60], ['brute', 71]]
      .map(([type, tx]) => ({ type, x: tx * T, y: fy }));
    return w;
  };
  DF.World = World;
})();
