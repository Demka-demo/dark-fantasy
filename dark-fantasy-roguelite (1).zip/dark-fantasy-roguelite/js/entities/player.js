// Игрок: движение + боевая машина состояний (move, attack, roll, hurt, drink, dead).
(function () {
  const DF = window.DF, C = DF.CONFIG, P = C.PLAYER, T = C.TILE, D = DF.DATA;
  const approach = (v, t, d) => v < t ? Math.min(v + d, t) : Math.max(v - d, t);
  class Player {
    constructor(x, y) { this.w = P.W; this.h = P.H; this.reset({ x, y }); }
    reset(pos) {
      this.x = pos.x; this.y = pos.y; this.vx = 0; this.vy = 0; this.facing = 1; this.onGround = false; this.jumping = false;
      this.coyote = 0; this.buffer = 0; this.dropTimer = 0; this.dropThrough = false;
      this.maxHp = this.hp = P.HP; this.maxSta = this.sta = P.STAMINA; this.staDelay = 0; this.estusMax = this.estus = P.ESTUS;
      this.state = 'move'; this.stateT = 0; this.atk = null; this.queued = null; this.invuln = 0; this.drank = false; this.rollDir = 1;
      this.safe = { x: pos.x, y: pos.y };
    }
    get iframes() { return this.invuln > 0 || (this.state === 'roll' && this.stateT >= D.ROLL.iframes[0] && this.stateT <= D.ROLL.iframes[1]); }
    setState(s) { this.state = s; this.stateT = 0; }
    spend(n) { this.sta = Math.max(0, this.sta - n); this.staDelay = P.STA_DELAY; }
    hurt(dmg, dir, knock) {
      if (this.state === 'dead' || this.iframes) return false;
      this.hp = Math.max(0, this.hp - dmg); this.invuln = P.INVULN; this.atk = null; this.queued = null;
      this.vx = dir * knock; this.vy = -160; this.setState(this.hp <= 0 ? 'dead' : 'hurt');
      return true;
    }
    // cmd: {left,right,down,jumpHeld,jumpPressed, press:{light,heavy,special,roll,heal}}
    update(dt, cmd, world) {
      const dir = (cmd.right ? 1 : 0) - (cmd.left ? 1 : 0), pr = cmd.press || {};
      this.invuln = Math.max(0, this.invuln - dt); this.stateT += dt;
      if (this.state !== 'attack' && this.state !== 'roll') {
        this.staDelay -= dt; if (this.staDelay <= 0) this.sta = Math.min(this.maxSta, this.sta + P.STA_REGEN * dt);
      }
      for (const k of ['light', 'heavy', 'special', 'roll', 'heal']) if (pr[k]) this.queued = { act: k, t: 0.3 };
      if (this.queued && (this.queued.t -= dt) <= 0) this.queued = null;

      const s = this.state;
      if (s === 'move') { this.locomotion(dt, cmd, dir, world); this.tryStart(dir, null); }
      else if (s === 'attack') this.attackUpdate(dt, dir);
      else if (s === 'roll') {
        const R = D.ROLL; this.vx = this.rollDir * R.speed * (1 - this.stateT / R.time * 0.5);
        if (this.stateT >= R.time) { this.vx *= 0.3; this.setState('move'); }
      } else if (s === 'hurt') {
        this.vx = approach(this.vx, 0, P.FRICTION * 0.5 * dt); if (this.stateT >= 0.28) this.setState('move');
      } else if (s === 'drink') {
        this.vx = approach(this.vx, dir * P.SPEED * 0.3, P.ACCEL * dt); if (dir) this.facing = dir;
        if (!this.drank && this.stateT >= 0.45) { this.drank = true; this.hp = Math.min(this.maxHp, this.hp + P.ESTUS_HEAL); }
        if (this.stateT >= 0.85) this.setState('move');
      } else this.vx = approach(this.vx, 0, P.FRICTION * dt);

      this.vy = Math.min(this.vy + C.GRAVITY * dt, C.MAX_FALL);
      this.dropTimer = Math.max(0, this.dropTimer - dt); this.dropThrough = this.dropTimer > 0;
      DF.Physics.move(this, world, dt);
      if (this.onGround || this.vy >= 0) this.jumping = false;
      if (this.onGround) { this.safe.x = this.x; this.safe.y = this.y; }
      if (this.y > world.pxH + 200 && this.state !== 'dead') { this.hp = 0; this.atk = null; this.setState('dead'); }   // падение в бездну
    }
    locomotion(dt, cmd, dir, world) {
      const k = this.onGround ? 1 : P.AIR;
      if (dir) { this.vx = approach(this.vx, dir * P.SPEED, P.ACCEL * k * dt); this.facing = dir; }
      else this.vx = approach(this.vx, 0, P.FRICTION * (this.onGround ? 1 : 0.3) * dt);
      this.coyote = this.onGround ? P.COYOTE : this.coyote - dt;
      this.buffer = cmd.jumpPressed ? P.BUFFER : this.buffer - dt;
      if (this.buffer > 0) {
        const below = world.get(Math.floor((this.x + this.w / 2) / T), Math.floor((this.y + this.h + 1) / T));
        if (cmd.down && this.onGround && below === 2) { this.dropTimer = P.DROP_TIME; this.buffer = 0; this.coyote = 0; }
        else if (this.coyote > 0) { this.vy = -P.JUMP; this.jumping = true; this.buffer = 0; this.coyote = 0; }
      }
      if (this.jumping && !cmd.jumpHeld && this.vy < 0) { this.vy *= P.JUMP_CUT; this.jumping = false; }
    }
    // Запуск действия из буфера. prev — текущая атака (для комбо и отмены восстановления).
    tryStart(dir, prev) {
      const q = this.queued; if (!q) return false;
      if (q.act === 'heal') {
        this.queued = null;
        if (this.estus > 0 && this.hp < this.maxHp && this.onGround) { this.estus--; this.drank = false; this.atk = null; this.setState('drink'); return true; }
        return false;
      }
      if (this.sta <= 0) return false;
      this.queued = null; this.atk = null;
      if (q.act === 'roll') {
        const d = dir || this.facing; this.facing = this.rollDir = d; this.spend(D.ROLL.stamina); this.setState('roll'); return true;
      }
      let idx = 0, def;
      if (q.act === 'light') { idx = prev && prev.act === 'light' ? (prev.idx + 1) % 3 : 0; def = D.ATTACKS.light[idx]; }
      else def = D.ATTACKS[q.act];
      if (dir) this.facing = dir;
      this.spend(def.stamina); this.atk = { act: q.act, idx, def, phase: 'windup', t: 0, hit: new Set() }; this.setState('attack');
      return true;
    }
    attackUpdate(dt, dir) {
      const a = this.atk, d = a.def; a.t += dt;
      if (a.phase === 'windup') {
        this.vx = approach(this.vx, 0, P.FRICTION * dt);
        if (a.t >= d.windup) { a.phase = 'active'; a.t = 0; this.vx = this.facing * d.lunge; }
      } else if (a.phase === 'active') {
        if (a.t >= d.active) { a.phase = 'recover'; a.t = 0; }
      } else {
        this.vx = approach(this.vx, 0, P.FRICTION * 0.6 * dt);
        if (this.queued && a.t >= d.recover * 0.45 && this.tryStart(dir, a)) return;   // комбо / отмена
        if (a.t >= d.recover) { this.atk = null; this.setState('move'); }
      }
    }
  }
  DF.Player = Player;
})();
