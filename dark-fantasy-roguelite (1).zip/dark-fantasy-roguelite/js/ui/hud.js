// Интерфейс поверх игры: полосы, фляги, души, подсказки, баннеры, экран смерти.
(function () {
  const DF = window.DF, C = DF.CONFIG;
  const text = (c, s, x, y, size, color, align) => {
    c.font = `${size}px Georgia`; c.textAlign = align || 'left'; c.lineWidth = 3; c.strokeStyle = '#000'; c.strokeText(s, x, y); c.fillStyle = color; c.fillText(s, x, y);
  };
  DF.HUD = {
    shop(c, g) {
      const W = C.VIEW_W, x = 150, y = 70, w = W - 300, h = 370, sh = g.shop, ids = DF.DATA.SHOP;
      c.fillStyle = 'rgba(8,6,12,0.93)'; c.fillRect(x, y, w, h); c.strokeStyle = '#6b5a3a'; c.lineWidth = 2; c.strokeRect(x + 1, y + 1, w - 2, h - 2);
      text(c, DF.DATA.TRADER.name, x + w / 2, y + 36, 24, '#e8c36a', 'center');
      text(c, `«${sh.line}»`, x + w / 2, y + 66, 14, '#a9a4b8', 'center');
      ids.forEach((id, k) => {
        const wp = DF.DATA.WEAPONS[id], ry = y + 90 + k * 96, sel = k === sh.sel, own = g.owned.has(id), eq = g.weapon === id, ic = DF.Assets.get(wp.icon);
        c.fillStyle = sel ? 'rgba(232,195,106,0.16)' : 'rgba(255,255,255,0.04)'; c.fillRect(x + 20, ry, w - 40, 84);
        if (sel) { c.strokeStyle = '#e8c36a'; c.lineWidth = 1; c.strokeRect(x + 20.5, ry + 0.5, w - 41, 83); }
        if (ic) c.drawImage(ic, x + 38, ry + 8, 16, 61);
        text(c, wp.name, x + 76, ry + 30, 20, '#f0e6cc'); text(c, `Урон ×${wp.mult}  ·  ${wp.desc}`, x + 76, ry + 56, 13, '#a9a4b8');
        const label = eq ? 'ЭКИПИРОВАНО' : own ? 'Выбрать' : `${wp.price} душ`;
        text(c, label, x + w - 40, ry + 44, 18, eq ? '#7fd17f' : own ? '#d9d2c0' : (g.souls >= wp.price ? '#e8d9a8' : '#c55'), 'right');
      });
      text(c, sh.msg, x + w / 2, y + h - 62, 16, '#e8c36a', 'center');
      text(c, `Ваши души: ${g.souls}`, x + 24, y + h - 20, 14, '#e8d9a8');
      text(c, 'W/S — выбор · Enter — купить / надеть · E, Esc — уйти', x + w - 24, y + h - 20, 13, '#8e8a9c', 'right');
    },
    draw(c, g) {
      const p = g.player, W = C.VIEW_W, H = C.VIEW_H;
      c.fillStyle = '#1a0c0e'; c.fillRect(16, 14, p.maxHp * 2.2 + 4, 16); c.fillStyle = '#b3262e'; c.fillRect(18, 16, p.hp * 2.2, 12);
      c.fillStyle = '#0d1a0d'; c.fillRect(16, 34, p.maxSta * 1.6 + 4, 10); c.fillStyle = '#4f9a4a'; c.fillRect(18, 36, p.sta * 1.6, 6);
      text(c, `Фляга (Q): ${p.estus}/${p.estusMax}`, 16, 62, 13, '#e0c27a');
      const wp = DF.DATA.WEAPONS[g.weapon], ic = DF.Assets.get(wp.icon);                   // текущее оружие
      if (ic) c.drawImage(ic, 18, 70, 9, 34); text(c, wp.name, 34, 92, 13, '#d9d2c0');
      text(c, `Души  ${g.souls}`, W - 20, H - 20, 20, '#e8d9a8', 'right');
      const nb = g.nearBonfire();
      const nn = g.nearNpc();
      if (nn && !nb && g.mode === 'play') text(c, 'E — Поговорить с торговцем', W / 2, H - 70, 18, '#f3e2b0', 'center');
      if (nb && g.mode === 'play') text(c, g.lit.has(nb.id) ? 'E — Отдохнуть у костра' : 'E — Зажечь костёр', W / 2, H - 70, 18, '#f3e2b0', 'center');
      if (g.banner.t > 0) { c.globalAlpha = Math.min(1, g.banner.t); text(c, g.banner.text, W / 2, H / 2 - 40, 34, '#e8c36a', 'center'); c.globalAlpha = 1; }
      if (g.mode === 'shop') this.shop(c, g);
      if (g.mode === 'dead') {
        const a = Math.min(1, g.deadT / 1.2); c.globalAlpha = a;
        c.fillStyle = 'rgba(0,0,0,0.75)'; c.fillRect(0, H / 2 - 70, W, 140);
        text(c, 'ВЫ ПОГИБЛИ', W / 2, H / 2 + 18, 56, '#a31b1b', 'center'); c.globalAlpha = 1;
      }
      if (g.fade > 0) { c.fillStyle = `rgba(0,0,0,${Math.min(1, g.fade)})`; c.fillRect(0, 0, W, H); }
      c.textAlign = 'left';
    }
  };
})();
