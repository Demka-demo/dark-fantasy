(function () {
  const DF = window.DF;
  class Input {
    constructor() {
      this.held = new Set(); this.hit = new Set();
      this.codes = new Set(Object.values(DF.CONFIG.KEYS).flat());
      window.addEventListener('keydown', e => {
        if (!this.codes.has(e.code)) return;
        e.preventDefault();
        if (!e.repeat) this.hit.add(e.code);
        this.held.add(e.code);
      });
      window.addEventListener('keyup', e => this.held.delete(e.code));
      window.addEventListener('blur', () => this.held.clear());
    }
    down(a) { return DF.CONFIG.KEYS[a].some(c => this.held.has(c)); }
    pressed(a) { return DF.CONFIG.KEYS[a].some(c => this.hit.has(c)); }
    endFrame() { this.hit.clear(); }
  }
  DF.Input = Input;
})();
