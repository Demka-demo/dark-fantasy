(function () {
  const DF = window.DF, C = DF.CONFIG;
  class Camera {
    constructor() { this.x = 0; this.y = 0; }
    target(t, world) {
      const x = t.x + t.w / 2 - C.VIEW_W / 2 + t.facing * 50;
      const y = t.y + t.h / 2 - C.VIEW_H / 2 - 30;
      return {
        x: Math.max(0, Math.min(world.pxW - C.VIEW_W, x)),
        y: Math.max(0, Math.min(world.pxH - C.VIEW_H, y))
      };
    }
    snap(t, world) { const p = this.target(t, world); this.x = p.x; this.y = p.y; }
    update(dt, t, world) {
      const p = this.target(t, world), k = 1 - Math.exp(-7 * dt);
      this.x += (p.x - this.x) * k; this.y += (p.y - this.y) * k;
    }
  }
  DF.Camera = Camera;
})();
