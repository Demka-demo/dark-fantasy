(function () {
  const DF = window.DF;
  DF.Assets.load(DF.CONFIG.ASSETS).then(() => new DF.Game(document.getElementById('game')).start());
})();
