// Сохранение в localStorage: последний костёр, зажжённые костры, души, пятно крови.
(function () {
  const DF = window.DF, KEY = 'dfr_save_v1';
  DF.Save = {
    load() { try { const s = JSON.parse(localStorage.getItem(KEY)); return s && s.v === 1 ? s : null; } catch (e) { return null; } },
    write(d) { try { localStorage.setItem(KEY, JSON.stringify(Object.assign({ v: 1 }, d))); } catch (e) { console.warn('Не удалось сохранить', e); } },
    clear() { try { localStorage.removeItem(KEY); } catch (e) { /* ignore */ } }
  };
})();
