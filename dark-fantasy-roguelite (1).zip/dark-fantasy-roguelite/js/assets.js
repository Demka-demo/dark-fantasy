// Загрузчик ресурсов. Отсутствующий файл не ломает игру: get() вернёт null, рендерер нарисует заглушку.
(function () {
  const DF = window.DF;
  const images = {};
  DF.Assets = {
    load(manifest) {
      const jobs = Object.entries(manifest).map(([key, src]) => new Promise(res => {
        const img = new Image();
        img.onload = () => { images[key] = img; res(); };
        img.onerror = () => { console.warn('Не найден ресурс:', src); res(); };
        img.src = src;
      }));
      return Promise.all(jobs);
    },
    get(key) { return images[key] || null; }
  };
})();
