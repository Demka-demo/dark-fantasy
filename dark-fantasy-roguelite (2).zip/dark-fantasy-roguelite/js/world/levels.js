// Уровни. Тайлы: 0 пусто, 1 камень, 2 доска (односторонняя), 3 лава. Координаты — в тайлах, S — ряд поверхности (верх земли).
// Уровень 1 «Проклятая цитадель»: врата (замок) → двор → колодец в канализацию → пещеры с лавой → подъём к таверне (безопасная зона).
(function () {
  const DF = window.DF, T = DF.CONFIG.TILE;
  DF.World.createLevel1 = function () {
    const W = 200, H = 36, w = new DF.World(W, H), px = r => r * T;
    const ground = (x0, x1, S) => w.rect(x0, S, x1 - x0, H - S, 1);
    let seed = 20261107; const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
    const scatter = (theme, x0, x1, S, pool, gap) => {
      for (let x = x0; x < x1; x += gap + Math.floor(rnd() * gap)) if (w.grid[S][x] === 1 && w.grid[S - 1][x] === 0) { const q = pool[Math.floor(rnd() * pool.length)]; w.prop(theme, q[0], q[1], x, S - 1); }
    };
    w.rect(0, 0, W, 1, 1); w.rect(0, 0, 1, H, 1); w.rect(W - 1, 0, 1, H, 1);

    // A. Врата (замок): руины, доски, первые враги
    ground(1, 81, 28);
    w.rect(14, 26, 4, 2, 1); w.rect(18, 25, 2, 3, 1);
    w.rect(22, 25, 6, 1, 2); w.rect(30, 22, 6, 1, 2); w.rect(38, 19, 6, 1, 2); w.rect(46, 22, 6, 1, 2); w.rect(53, 25, 5, 1, 2);
    // B. Двор: терраса, доски над ней, обрыв-колодец (x 81–86) в канализацию
    ground(58, 70, 25); w.rect(60, 22, 6, 1, 2);
    // C. Канализация: низкий свод (ряды 0–25), пол S=33
    ground(81, 121, 33); w.rect(87, 0, 84, 26, 1);
    w.rect(92, 30, 6, 1, 2); w.rect(104, 30, 6, 1, 2); w.rect(100, 31, 3, 2, 1);
    // D. Пещеры с лавой: ямы A, B, C с каменными «островами», потом подъём ступенями
    ground(121, 126, 33); ground(133, 141, 33); ground(149, 159, 33); ground(167, 171, 33);
    [[126, 7], [141, 8], [159, 8]].forEach(([x, n]) => { w.rect(x, 34, n, 1, 3); w.rect(x, 35, n, 1, 1); });   // лава в один ряд, дно под ней
    w.rect(127, 32, 2, 2, 1); w.rect(131, 32, 2, 2, 1);                  // ямa A
    w.rect(142, 32, 2, 2, 1); w.rect(146, 31, 2, 3, 1);                  // яма B
    w.rect(160, 31, 3, 1, 2); w.rect(164, 31, 3, 1, 2);                  // яма C: доски
    for (let i = 0; i < 5; i++) ground(171 + i, 172 + i, 32 - i);        // подъём к таверне
    ground(176, W, 28);
    w.tavern(177, 28); w.safeX = 177 * T;

    w.zones = [{ x0: 0, x1: 81, theme: 'castle' }, { x0: 81, x1: 121, theme: 'sewer' }, { x0: 121, x1: 177, theme: 'inferno' }, { x0: 177, x1: W, theme: 'castle' }];
    w.spawn = { x: 3 * T, y: px(28) - DF.CONFIG.PLAYER.H };
    w.bonfires = [{ id: 'ruins', name: 'Руины у входа', x: 5 * T + 16, y: px(28) }, { id: 'court', name: 'Разрушенный двор', x: 78 * T + 16, y: px(28) },
      { id: 'sewer', name: 'Сток под цитаделью', x: 90 * T + 16, y: px(33) }, { id: 'forge', name: 'Горн', x: 123 * T + 16, y: px(33) },
      { id: 'haven', name: 'Тихая обитель', x: 183 * T + 16, y: px(28) }];
    w.npcs = [{ type: 'trader', x: 190 * T, y: px(28) }];
    const sp = (type, tx, S, fly) => ({ type, x: tx * T, y: fly ? px(S) + 12 : px(S) });   // у летающих S — ряд высоты парения
    w.spawns = [sp('hollow', 22, 28), sp('hollow', 34, 28), sp('wolf', 41, 28), sp('hollow', 50, 28),
      sp('hollow', 62, 25), sp('demon', 64, 19, 1), sp('wolf', 66, 25), sp('hollow', 74, 28),
      sp('wolf', 96, 33), sp('demon', 100, 28, 1), sp('wolf', 106, 33), sp('brute', 115, 33),
      sp('demon', 129, 30, 1), sp('hollow', 136, 33), sp('demon', 145, 29, 1), sp('hollow', 152, 33), sp('brute', 155, 33), sp('demon', 162, 29, 1), sp('wolf', 169, 33)];

    // Декор
    const castle = [[4, 2], [4, 3], [0, 6], [1, 6], [5, 3], [7, 1], [5, 0], [5, 1]];
    scatter('castle', 8, 80, 28, castle, 7); scatter('castle', 58, 70, 25, castle, 6);
    w.prop('castle', 5, 0, 79, 27); w.prop('castle', 5, 0, 3, 27);
    scatter('sewer', 88, 120, 33, [[4, 2], [5, 3], [7, 1]], 8);
    for (let x = 90; x < 120; x += 9 + Math.floor(rnd() * 4)) w.prop('sewer', 6 + (x & 1), 3, x, 26);       // слизь со свода
    scatter('inferno', 122, 170, 33, [[7, 1], [5, 1]], 9);
    for (let x = 123; x < 170; x += 8 + Math.floor(rnd() * 4)) { w.prop('inferno', 7, 2, x, 26); w.prop('inferno', 7, 2, x, 27); }   // жилы с потолка
    w.findLava();
    return w;
  };
  DF.World.createLevel = id => ({ 1: DF.World.createLevel1 }[id] || DF.World.createLevel1)();
})();
