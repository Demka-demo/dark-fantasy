// Диалог с NPC: портрет героя (меняется по эмоции), портрет собеседника, печатающийся текст, выбор ответа.
// Тексты и эмоции — в DF.DATA.DIALOGUE. После диалога торговца открывается лавка.
(function () {
  const DF = window.DF, C = DF.CONFIG, W = C.VIEW_W, H = C.VIEW_H;
  class Dialogue {
    constructor(game) { this.g = game; this.id = null; this.lines = []; this.i = 0; this.chars = 0; this.stage = 'lines'; this.sel = 0; this.t = 0; this.closing = false; }
    open(id) {
      const D = DF.DATA.DIALOGUE[id], g = this.g; this.id = id; this.lines = (g.met[id] ? D.again : D.first).slice();
      this.i = 0; this.chars = 0; this.stage = 'lines'; this.sel = 0; this.t = 0; this.closing = false; g.met[id] = true; g.persist(); g.mode = 'dialog'; g.player.vx = 0;
    }
    cur() { return this.lines[this.i]; }
    close() { this.g.mode = 'play'; this.g.queue = {}; }
    choose(id) {
      if (id === 'trade') this.g.openShop();
      else { this.lines = DF.DATA.DIALOGUE[this.id].farewell.slice(); this.i = 0; this.chars = 0; this.stage = 'lines'; this.closing = true; }
    }
    update(dt, i) {
      this.t += dt;
      if (i.pressed('cancel')) { this.close(); return; }
      if (this.stage === 'lines') {
        const L = this.cur(); this.chars = Math.min(L.text.length, this.chars + dt * 48);
        if (i.pressed('accept')) {
          if (this.chars < L.text.length) this.chars = L.text.length;
          else { this.i++; this.chars = 0; if (this.i >= this.lines.length) { if (this.closing) this.close(); else { this.stage = 'choices'; this.sel = 0; } } }
        }
      } else {
        const n = DF.DATA.DIALOGUE[this.id].choices.length;
        if (i.pressed('down')) this.sel = (this.sel + 1) % n; if (i.pressed('up')) this.sel = (this.sel + n - 1) % n;
        if (i.pressed('accept')) this.choose(DF.DATA.DIALOGUE[this.id].choices[this.sel].id);
      }
    }
    wrap(c, text, maxW) {
      const out = []; let line = '';
      for (const w of text.split(' ')) { const t = line ? line + ' ' + w : w; if (c.measureText(t).width > maxW && line) { out.push(line); line = w; } else line = t; }
      if (line) out.push(line); return out;
    }
    draw(c) {
      const D = DF.DATA.DIALOGUE[this.id], L = this.stage === 'lines' ? this.cur() : { who: 'npc' }, speakerHero = L.who === 'hero';
      const px = 40, py = 350, pw = W - 80, ph = 160, t = this.t;
      c.fillStyle = 'rgba(0,0,0,0.38)'; c.fillRect(0, 0, W, H);
      const g = c.createLinearGradient(0, py, 0, py + ph); g.addColorStop(0, 'rgba(18,14,24,0.96)'); g.addColorStop(1, 'rgba(8,6,12,0.97)'); c.fillStyle = g; c.fillRect(px, py, pw, ph);
      c.strokeStyle = '#6b5a3a'; c.lineWidth = 2; c.strokeRect(px + 1, py + 1, pw - 2, ph - 2); c.strokeStyle = 'rgba(232,195,106,0.25)'; c.lineWidth = 1; c.strokeRect(px + 6.5, py + 6.5, pw - 13, ph - 13);
      // портрет героя
      const emo = (speakerHero && L.emo) || (this.hero || 'calm'); if (speakerHero) this.hero = emo;
      const pic = DF.Assets.get('portrait_' + (this.hero || emo));
      c.save(); c.globalAlpha = speakerHero ? 1 : 0.5;
      if (pic) c.drawImage(pic, px + 12, py + ph - 8 - pic.height * 1.5 - (speakerHero ? 6 : 0), pic.width * 1.5, pic.height * 1.5);
      c.restore();
      // портрет собеседника (крупный кадр торговца)
      c.save(); c.globalAlpha = speakerHero ? 0.5 : 1;
      const cfg = C.NPC.trader; if (DF.Sprites.has('trader')) DF.Sprites.draw(c, { skin: 'trader', key: 'talk', frame: DF.Sprites.loop(cfg.talk, t), x: px + pw - 100, y: py + ph - 8 - (speakerHero ? 0 : 6), flip: -1, scale: 3, ax: cfg.ax, ay: cfg.ay });
      c.restore();
      // имя и текст
      const tx = px + 230, tw = pw - 230 - 190;
      c.textAlign = 'left'; c.font = 'bold 17px Georgia'; c.fillStyle = speakerHero ? '#9fd8ff' : '#e8c36a'; c.fillText(speakerHero ? DF.DATA.HERO_NAME : D.name, tx, py + 34);
      c.font = '17px Georgia'; c.fillStyle = '#f0e6cc';
      if (this.stage === 'lines') {
        const lines = this.wrap(c, L.text.slice(0, Math.floor(this.chars)), tw); lines.forEach((s, k) => c.fillText(s, tx, py + 64 + k * 26));
        if (this.chars >= L.text.length && Math.sin(t * 6) > -0.3) { c.fillStyle = '#e8c36a'; c.fillText('▼', tx + tw - 4, py + ph - 20); }
      } else {
        D.choices.forEach((ch, k) => {
          const y = py + 62 + k * 38, sel = k === this.sel;
          if (sel) { c.fillStyle = 'rgba(232,195,106,0.16)'; c.fillRect(tx - 12, y - 22, tw, 32); c.fillStyle = '#e8c36a'; c.beginPath(); c.moveTo(tx - 6, y - 12); c.lineTo(tx + 2, y - 6); c.lineTo(tx - 6, y); c.fill(); }
          c.fillStyle = sel ? '#f6e2a0' : '#a9a4b8'; c.fillText(ch.label, tx + 12, y);
        });
      }
      c.textAlign = 'left';
    }
  }
  DF.Dialogue = Dialogue;
})();
