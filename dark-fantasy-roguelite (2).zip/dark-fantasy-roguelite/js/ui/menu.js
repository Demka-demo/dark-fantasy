// Главное меню и пауза: анимированный фон (параллакс, туман, молнии, угли), герой у костра, пункты с мышью и клавиатурой.
(function () {
  const DF = window.DF, C = DF.CONFIG, W = C.VIEW_W, H = C.VIEW_H;
  const CONTROLS = [['Движение', 'A / D, ← / →'], ['Прыжок', 'Space, W, ↑'], ['Быстрый удар (комбо ×3)', 'J'], ['Тяжёлый удар', 'K'], ['Удар щитом', 'L'], ['Перекат', 'Shift, C'],
    ['Фляга', 'Q'], ['Способность клинка', 'R'], ['Костёр, торговец', 'E'], ['Пауза / назад', 'Esc'], ['Отладка', 'F3'], ['Стереть сохранение', 'F9']];
  class Menu {
    constructor(game) {
      this.g = game; this.sel = 0; this.view = 'main'; this.pause = false; this.t = 0; this.hit = []; this.embers = []; this.flash = 0; this.nextFlash = 3;
      const cv = game.renderer.ctx.canvas;
      const at = e => { const r = cv.getBoundingClientRect(), x = (e.clientX - r.left) * W / r.width, y = (e.clientY - r.top) * H / r.height; return this.hit.find(q => x >= q.x && x <= q.x + q.w && y >= q.y && y <= q.y + q.h); };
      cv.addEventListener('mousemove', e => { if (!this.active() || this.view === 'controls') return; const h = at(e); if (h && !this.items()[h.i].off) this.sel = h.i; });
      cv.addEventListener('click', e => { if (!this.active()) return; if (this.view === 'controls') { this.back(); return; } const h = at(e); if (h) { this.sel = h.i; this.activate(); } });
    }
    active() { return this.g.mode === 'menu' || this.g.mode === 'pause'; }
    items() {
      if (this.view === 'confirm') return [{ id: 'yes', label: 'Да, начать заново' }, { id: 'no', label: 'Отмена' }];
      if (this.pause) return [{ id: 'resume', label: 'Вернуться в игру' }, { id: 'controls', label: 'Управление' }, { id: 'tomenu', label: 'В главное меню' }];
      return [{ id: 'continue', label: 'Продолжить', off: !DF.Save.load() }, { id: 'new', label: 'Новая игра' }, { id: 'controls', label: 'Управление' }];
    }
    open() { this.pause = false; this.view = 'main'; this.sel = DF.Save.load() ? 0 : 1; this.t = 0; }
    openPause() { this.pause = true; this.view = 'main'; this.sel = 0; }
    back() { this.view = 'main'; this.sel = 0; }
    move(d) { const it = this.items(); let k = this.sel; for (let n = 0; n < it.length; n++) { k = (k + d + it.length) % it.length; if (!it[k].off) break; } this.sel = k; }
    activate() {
      const it = this.items()[this.sel], g = this.g; if (!it || it.off) return;
      if (it.id === 'continue') g.startPlay();
      else if (it.id === 'new') { if (DF.Save.load()) { this.view = 'confirm'; this.sel = 1; } else g.newGame(); }
      else if (it.id === 'yes') g.newGame();
      else if (it.id === 'no') { this.view = 'main'; this.sel = 1; }
      else if (it.id === 'controls') this.view = 'controls';
      else if (it.id === 'resume') g.mode = 'play';
      else if (it.id === 'tomenu') { g.persist(); g.mode = 'menu'; this.open(); }
    }
    update(dt, i) {
      this.t += dt; this.nextFlash -= dt;
      if (this.nextFlash <= 0) { this.flash = 1; this.nextFlash = 6 + Math.random() * 8; }
      this.flash = Math.max(0, this.flash - dt * 1.6);
      if (!this.pause && Math.random() < dt * 40) this.embers.push({ x: Math.random() * W, y: H + 5, vx: (Math.random() - 0.5) * 20, vy: -(25 + Math.random() * 45), s: 1 + Math.random() * 2, t: 0, life: 4 + Math.random() * 4 });
      for (const e of this.embers) { e.t += dt; e.x += (e.vx + Math.sin(e.t * 2 + e.y) * 12) * dt; e.y += e.vy * dt; }
      this.embers = this.embers.filter(e => e.t < e.life);
      if (this.view === 'controls') { if (i.pressed('cancel') || i.pressed('accept')) this.back(); return; }
      if (this.view === 'confirm' && i.pressed('cancel')) { this.view = 'main'; this.sel = 1; return; }
      if (this.pause && this.view === 'main' && i.pressed('cancel')) { this.g.mode = 'play'; return; }
      if (i.pressed('down')) this.move(1);
      if (i.pressed('up')) this.move(-1);
      if (i.pressed('accept')) this.activate();
    }
    text(c, s, x, y, size, color, align, weight) { c.font = `${weight || ''} ${size}px Georgia`; c.textAlign = align || 'center'; c.fillStyle = color; c.fillText(s, x, y); }
    drawScene(c, R) {
      const t = this.t; R.background({ x: t * 16, y: 0 });
      for (let k = 0; k < 3; k++) {                                                    // туман
        const x = ((t * (8 + k * 5) + k * 400) % (W + 600)) - 300, y = 330 + k * 60, g = c.createRadialGradient(W - x, y, 10, W - x, y, 320);
        g.addColorStop(0, `rgba(150,160,190,${0.10 - k * 0.02})`); g.addColorStop(1, 'rgba(150,160,190,0)'); c.fillStyle = g; c.fillRect(0, y - 200, W, 400);
      }
      c.fillStyle = '#05060a'; c.beginPath(); c.moveTo(0, H);                         // силуэт земли
      for (let x = 0; x <= W; x += 20) c.lineTo(x, H - 62 + Math.sin(x * 0.021) * 9 + Math.sin(x * 0.06) * 4 - (x < 360 ? 14 : 0));
      c.lineTo(W, H); c.fill();
      const fire = { x: 330, y: H - 66 };
      if (DF.Sprites.has(C.SPRITE.skin)) DF.Sprites.draw(c, { skin: C.SPRITE.skin, key: 'idle', frame: DF.Sprites.loop(C.ANIMS.idle, t), x: 250, y: H - 58, flip: 1, scale: 1.6 });
      R.bonfire(fire, true, t);
      for (const e of this.embers) { c.globalCompositeOperation = 'lighter'; c.globalAlpha = Math.min(1, e.t) * Math.min(1, (e.life - e.t)) * 0.8; c.fillStyle = '#ff9a3a'; c.fillRect(Math.round(e.x), Math.round(e.y), e.s, e.s); }
      c.globalCompositeOperation = 'source-over'; c.globalAlpha = 1;
      if (this.flash > 0) { c.fillStyle = `rgba(190,205,255,${this.flash * 0.22})`; c.fillRect(0, 0, W, H); }
      c.fillStyle = R.vignette; c.fillRect(0, 0, W, H);
    }
    title(c) {
      const t = this.t, flick = Math.sin(t * 3.1) > 0.96 ? 0.6 : 1;
      c.save(); c.globalAlpha = Math.min(1, t / 1.2) * flick; c.textAlign = 'center';
      c.shadowColor = '#ff7a2a'; c.shadowBlur = 22 + 10 * Math.sin(t * 2);
      const g = c.createLinearGradient(0, 70, 0, 150); g.addColorStop(0, '#f6e2a0'); g.addColorStop(0.55, '#d08a2e'); g.addColorStop(1, '#7a2a12');
      c.font = 'bold 76px Georgia'; if ('letterSpacing' in c) c.letterSpacing = '6px'; c.fillStyle = g; c.fillText(C.TITLE.main, W / 2, 140);
      c.shadowBlur = 0; c.font = '26px Georgia'; if ('letterSpacing' in c) c.letterSpacing = '18px'; c.fillStyle = '#a89a80'; c.fillText(C.TITLE.sub, W / 2 + 9, 184);
      if ('letterSpacing' in c) c.letterSpacing = '0px';
      c.strokeStyle = 'rgba(208,138,46,0.7)'; c.lineWidth = 1; const w = 150 + 6 * Math.sin(t * 2);   // орнамент
      c.beginPath(); c.moveTo(W / 2 - 260, 204); c.lineTo(W / 2 - 14, 204); c.moveTo(W / 2 + 14, 204); c.lineTo(W / 2 + 260, 204); c.stroke();
      c.fillStyle = '#d08a2e'; c.beginPath(); c.moveTo(W / 2, 197); c.lineTo(W / 2 + 7, 204); c.lineTo(W / 2, 211); c.lineTo(W / 2 - 7, 204); c.fill();
      c.restore();
    }
    list(c, y0) {
      const it = this.items(), t = this.t; this.hit = [];
      it.forEach((m, i) => {
        const y = y0 + i * 54, sel = i === this.sel, a = Math.min(1, Math.max(0, (t - 0.5 - i * 0.15) * 2.5));
        c.save(); c.globalAlpha = a; c.textAlign = 'center';
        if (sel && !m.off) { c.shadowColor = '#ff9a3a'; c.shadowBlur = 14 + 6 * Math.sin(t * 5); }
        this.text(c, m.label, W / 2, y, sel ? 32 : 28, m.off ? '#4a4658' : sel ? '#f6e2a0' : '#9a9486');
        c.shadowBlur = 0;
        if (sel && !m.off) {                                                            // ромбы-«огоньки» по бокам
          const tw = c.measureText(m.label).width / 2 + 28, k = 1 + 0.2 * Math.sin(t * 6);
          c.fillStyle = '#ff9a3a'; for (const s of [-1, 1]) { c.beginPath(); c.moveTo(W / 2 + s * tw, y - 11 - 5 * k); c.lineTo(W / 2 + s * (tw + 6 * k), y - 11); c.lineTo(W / 2 + s * tw, y - 11 + 5 * k); c.lineTo(W / 2 + s * (tw - 6 * k), y - 11); c.fill(); }
        }
        c.restore(); this.hit.push({ i, x: W / 2 - 170, y: y - 30, w: 340, h: 44 });
      });
    }
    controls(c) {
      c.fillStyle = 'rgba(8,6,12,0.88)'; c.fillRect(190, 80, W - 380, 390); c.strokeStyle = '#6b5a3a'; c.lineWidth = 2; c.strokeRect(191, 81, W - 382, 388);
      this.text(c, 'Управление', W / 2, 124, 30, '#e8c36a');
      CONTROLS.forEach(([a, b], i) => { const y = 168 + i * 25; this.text(c, a, 230, y, 16, '#c9c2b0', 'left'); this.text(c, b, W - 230, y, 16, '#f0e6cc', 'right'); });
      this.text(c, 'Esc / Enter — назад', W / 2, 452, 13, '#8e8a9c');
    }
    draw(c, g, R) {
      if (this.pause) { c.fillStyle = 'rgba(0,0,0,0.62)'; c.fillRect(0, 0, W, H); } else this.drawScene(c, R);
      if (this.view === 'controls') { this.controls(c); }
      else {
        if (!this.pause) this.title(c); else { this.text(c, 'ПАУЗА', W / 2, 180, 52, '#e8c36a', 'center', 'bold'); }
        if (this.view === 'confirm') this.text(c, 'Прогресс будет стёрт. Продолжить?', W / 2, this.pause ? 250 : 262, 20, '#c9c2b0');
        this.list(c, this.pause ? 270 : (this.view === 'confirm' ? 320 : 300));
        if (!this.pause) this.text(c, '↑ ↓ — выбор · Enter — подтвердить · мышь', W / 2, H - 22, 13, '#6d6a78');
      }
      if (!this.pause && this.t < 1) { c.fillStyle = `rgba(0,0,0,${1 - this.t})`; c.fillRect(0, 0, W, H); }
      c.textAlign = 'left';
    }
  }
  DF.Menu = Menu;
})();
