// Интерфейс поверх игры: полосы, фляги, души, подсказки, баннеры, экран смерти.
(function () {
  const DF = window.DF, C = DF.CONFIG;
  const text = (c, s, x, y, size, color, align) => {
    c.font = `${size}px Georgia`; c.textAlign = align || 'left'; c.lineWidth = 3; c.strokeStyle = '#000'; c.strokeText(s, x, y); c.fillStyle = color; c.fillText(s, x, y);
  };
  DF.HUD = {
    shop(c, g) {
      const W = C.VIEW_W, x = 150, y = 40, w = W - 300, h = 460, sh = g.shop, ids = DF.DATA.SHOP, E = DF.DATA.ENCHANT;
      c.fillStyle = 'rgba(8,6,12,0.93)'; c.fillRect(x, y, w, h); c.strokeStyle = '#6b5a3a'; c.lineWidth = 2; c.strokeRect(x + 1, y + 1, w - 2, h - 2);
      text(c, DF.DATA.TRADER.name, x + w / 2, y + 36, 24, '#e8c36a', 'center');
      text(c, `«${sh.line}»`, x + w / 2, y + 66, 14, '#a9a4b8', 'center');
      if (sh.view === 'offers') {                                                       // выбор способности
        const cost = g.ability ? E.recost : E.cost;
        text(c, `Зачарование клинка — ${cost} изумрудов`, x + w / 2, y + 96, 18, '#6fe0a0', 'center');
        sh.offers.forEach((id, k) => {
          const ab = DF.DATA.ABILITIES[id], ry = y + 116 + k * 84, sel = k === sh.sel;
          c.fillStyle = sel ? 'rgba(111,224,160,0.16)' : 'rgba(255,255,255,0.04)'; c.fillRect(x + 20, ry, w - 40, 74);
          if (sel) { c.strokeStyle = '#6fe0a0'; c.lineWidth = 1; c.strokeRect(x + 20.5, ry + 0.5, w - 41, 73); }
          text(c, ab.name, x + 40, ry + 30, 20, '#f0e6cc'); text(c, ab.desc, x + 40, ry + 58, 13, '#a9a4b8');
          text(c, ab.type === 'active' ? 'АКТИВНАЯ · R' : 'ПАССИВНАЯ', x + w - 40, ry + 30, 13, ab.type === 'active' ? '#ffb060' : '#9fd8ff', 'right');
        });
        text(c, sh.msg, x + w / 2, y + h - 62, 16, '#e8c36a', 'center');
        text(c, `Изумруды: ${g.emeralds}`, x + 24, y + h - 20, 14, '#6fe0a0');
        text(c, 'W/S — выбор · Enter — зачаровать · Esc — назад', x + w - 24, y + h - 20, 13, '#8e8a9c', 'right');
        return;
      }
      ids.forEach((id, k) => {
        if (id === 'enchant') {
          const ry = y + 90 + k * 96, sel = k === sh.sel, ab = DF.DATA.ABILITIES[g.ability];
          c.fillStyle = sel ? 'rgba(111,224,160,0.16)' : 'rgba(255,255,255,0.04)'; c.fillRect(x + 20, ry, w - 40, 84);
          if (sel) { c.strokeStyle = '#6fe0a0'; c.lineWidth = 1; c.strokeRect(x + 20.5, ry + 0.5, w - 41, 83); }
          text(c, 'Зачарование клинка', x + 40, ry + 30, 20, '#c9f0d6');
          text(c, ab ? `Сейчас: ${ab.name}. Можно заменить.` : 'Вложите изумруды — получите способность на выбор.', x + 40, ry + 56, 13, '#a9a4b8');
          const cost = g.ability ? E.recost : E.cost; text(c, `${cost} изумрудов`, x + w - 40, ry + 44, 18, g.emeralds >= cost ? '#6fe0a0' : '#c55', 'right');
          return;
        }
        const wp = DF.DATA.WEAPONS[id], ry = y + 90 + k * 96, sel = k === sh.sel, own = g.owned.has(id), eq = g.weapon === id, ic = DF.Assets.get(wp.icon);
        c.fillStyle = sel ? 'rgba(232,195,106,0.16)' : 'rgba(255,255,255,0.04)'; c.fillRect(x + 20, ry, w - 40, 84);
        if (sel) { c.strokeStyle = '#e8c36a'; c.lineWidth = 1; c.strokeRect(x + 20.5, ry + 0.5, w - 41, 83); }
        if (ic) c.drawImage(ic, x + 38, ry + 8, 16, 61);
        text(c, wp.name, x + 76, ry + 30, 20, '#f0e6cc'); text(c, `Урон ×${wp.mult}  ·  ${wp.desc}`, x + 76, ry + 56, 13, '#a9a4b8');
        const label = eq ? 'ЭКИПИРОВАНО' : own ? 'Выбрать' : `${wp.price} душ`;
        text(c, label, x + w - 40, ry + 44, 18, eq ? '#7fd17f' : own ? '#d9d2c0' : (g.souls >= wp.price ? '#e8d9a8' : '#c55'), 'right');
      });
      text(c, sh.msg, x + w / 2, y + h - 62, 16, '#e8c36a', 'center');
      text(c, `Души: ${g.souls}   Изумруды: ${g.emeralds}`, x + 24, y + h - 20, 14, '#e8d9a8');
      text(c, 'W/S — выбор · Enter — купить / надеть · E, Esc — уйти', x + w - 24, y + h - 20, 13, '#8e8a9c', 'right');
    },
    draw(c, g) {
      const p = g.player, W = C.VIEW_W, H = C.VIEW_H;
      c.fillStyle = '#1a0c0e'; c.fillRect(16, 14, p.maxHp * 2.2 + 4, 16); c.fillStyle = '#b3262e'; c.fillRect(18, 16, p.hp * 2.2, 12);
      c.fillStyle = '#0d1a0d'; c.fillRect(16, 34, p.maxSta * 1.6 + 4, 10); c.fillStyle = '#4f9a4a'; c.fillRect(18, 36, p.sta * 1.6, 6);
      text(c, `Фляга (Q): ${p.estus}/${p.estusMax}`, 16, 62, 13, '#e0c27a');
      const wp = DF.DATA.WEAPONS[g.weapon], ic = DF.Assets.get(wp.icon);                   // текущее оружие
      if (ic) c.drawImage(ic, 18, 70, 9, 34); text(c, wp.name, 34, 92, 13, '#d9d2c0');
      text(c, `Души  ${g.souls}`, W - 20, H - 20, 20, '#e8d9a8', 'right');
      text(c, `Изумруды  ${g.emeralds}`, W - 20, H - 46, 16, '#6fe0a0', 'right');
      const ab = DF.DATA.ABILITIES[g.ability];                                          // слот способности клинка
      if (ab) {
        c.fillStyle = 'rgba(8,6,12,0.7)'; c.fillRect(16, H - 78, 210, 50); c.strokeStyle = '#3d6a55'; c.lineWidth = 1; c.strokeRect(16.5, H - 77.5, 209, 49);
        text(c, ab.name, 24, H - 58, 14, '#c9f0d6');
        if (ab.type === 'active') {
          const rdy = g.abilityCd <= 0; text(c, rdy ? 'R — готово' : `R — ${g.abilityCd.toFixed(1)} с`, 24, H - 38, 12, rdy ? '#6fe0a0' : '#a9a4b8');
          c.fillStyle = '#16231c'; c.fillRect(110, H - 46, 108, 6); c.fillStyle = '#4fd08a'; c.fillRect(110, H - 46, 108 * (1 - g.abilityCd / ab.cd), 6);
        } else text(c, 'пассивная способность', 24, H - 38, 12, '#a9a4b8');
      }
      const nb = g.nearBonfire();
      const nn = g.nearNpc();
      if (nn && !nb && g.mode === 'play') text(c, 'E — Поговорить с торговцем', W / 2, H - 70, 18, '#f3e2b0', 'center');
      if (nb && g.mode === 'play') text(c, g.lit.has(nb.id) ? 'E — Отдохнуть у костра' : 'E — Зажечь костёр', W / 2, H - 70, 18, '#f3e2b0', 'center');
      if (g.banner.t > 0) { c.globalAlpha = Math.min(1, g.banner.t); text(c, g.banner.text, W / 2, H / 2 - 40, 34, '#e8c36a', 'center'); c.globalAlpha = 1; }
      if (g.mode === 'shop') this.shop(c, g);
      if (g.mode === 'dead') {
        const a = Math.min(1, g.deadT / 1.2); c.globalAlpha = a;
        c.fillStyle = 'rgba(0,0,0,0.75)'; c.fillRect(0, H / 2 - 70, W, 140);
        text(c, 'ВЫ ПОГИБЛИ', W / 2, H / 2 + 18, 56, '#a31b1b', 'center'); c.globalAlpha = 1;
      }
      if (g.fade > 0) { c.fillStyle = `rgba(0,0,0,${Math.min(1, g.fade)})`; c.fillRect(0, 0, W, H); }
      c.textAlign = 'left';
    }
  };
})();
