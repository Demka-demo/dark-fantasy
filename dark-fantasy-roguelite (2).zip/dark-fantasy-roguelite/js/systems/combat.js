// Хитбоксы и применение урона. Один удар поражает цель один раз (atk.hit для игрока, hitDone для врага).
(function () {
  const DF = window.DF;
  DF.Combat = {
    overlap(a, b) { return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y; },
    box(o, w, h) { return { x: o.facing > 0 ? o.x + o.w : o.x - w, y: o.y + o.h - h, w, h }; },
    update(game) {
      const p = game.player, a = p.atk;
      if (p.state === 'attack' && a.phase === 'active') {
        const b = this.box(p, a.def.w, a.def.h), wp = DF.DATA.WEAPONS[game.weapon];
        const def = Object.assign({}, a.def, { damage: Math.round(a.def.damage * wp.mult * game.dmgMult()) });
        for (const e of game.enemies) {
          if (e.dead || a.hit.has(e) || !this.overlap(b, e)) continue;
          a.hit.add(e);
          game.onEnemyHit(e, def, p.facing, e.hurt(def, p.facing));
        }
        for (const s of game.enemyShots) if (!s.dead && this.overlap(b, { x: s.x - 10, y: s.y - 8, w: 20, h: 16 })) { s.dead = true; game.sparks(s.x, s.y, ['#ffb347', '#ffffff'], 8, 3, true); }   // удар сбивает снаряд
      }
      for (const e of game.enemies) {
        if (e.state !== 'attack' || e.hitDone || e.d.ranged) continue;
        const hb = e.d.flying ? { x: e.x - 6, y: e.y - 6, w: e.w + 12, h: e.h + 12 } : this.box(e, e.d.hitW, e.d.hitH);
        if (!this.overlap(hb, p)) continue;
        e.hitDone = true;
        if (p.hurt(e.d.dmg, e.facing, e.d.knock)) game.onPlayerHit(e);
      }
    }
  };
})();
