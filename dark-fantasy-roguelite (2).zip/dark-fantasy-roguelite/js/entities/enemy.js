// Один класс врага, поведение задаётся данными из DF.DATA.ENEMIES.
// Состояния: patrol → chase → windup (телеграф) → attack → recover; stagger при сбивании; dead.
(function () {
  const DF = window.DF, C = DF.CONFIG, T = C.TILE;
  class Enemy {
    constructor(type, cx, feetY) {
      const d = DF.DATA.ENEMIES[type];
      this.type = type; this.d = d; this.w = d.w; this.h = d.h; this.x = cx - d.w / 2; this.y = feetY - d.h;
      this.vx = 0; this.vy = 0; this.hp = d.hp; this.home = cx; this.dir = Math.random() < 0.5 ? -1 : 1; this.facing = this.dir;
      this.state = 'patrol'; this.t = 0; this.cd = 0; this.hurtFlash = 0; this.dead = false; this.deadT = 0; this.hitDone = false; this.onGround = false; this.homeY = this.y + this.h / 2;
    }
    ahead(world, dy) { return world.get(Math.floor((this.x + (this.facing > 0 ? this.w + 3 : -3)) / T), Math.floor((this.y + dy) / T)); }
    blocked(world) { return this.ahead(world, this.h / 2) === 1 || (this.onGround && (this.ahead(world, this.h + 4) === 0 || this.ahead(world, this.h + 4) === 3)); }
    hurt(def, dir) {
      this.hp -= def.damage; this.hurtFlash = 0.12;
      if (this.hp <= 0) { this.dead = true; this.state = 'dead'; this.vx = dir * def.knock * 0.5; if (this.d.noFall) this.vy = 0; return 'kill'; }
      if (def.stagger >= this.d.poise) { this.state = 'stagger'; this.t = 0; this.vx = dir * def.knock; this.vy = -120; return 'stagger'; }
      this.vx += dir * def.knock * 0.2;
      if (this.state === 'patrol') this.state = 'chase';
      return 'hit';
    }
    clearShot(world, x0, y0, x1, y1) {                                               // нет ли стены на линии огня
      for (let k = 1; k < 12; k++) if (world.get(Math.floor((x0 + (x1 - x0) * k / 12) / T), Math.floor((y0 + (y1 - y0) * k / 12) / T)) === 1) return false;
      return true;
    }
    // Полёт: парит над домом, преследует на высоте, пикирует на игрока по прямой (замах → рывок → отход вверх).
    fly(dt, world, player, dist, sees, alive, inSafe) {
      const d = this.d, cx = this.x + this.w / 2, cy = this.y + this.h / 2, px = player.x + player.w / 2, py = player.y + player.h / 2, bob = Math.sin(this.t * 4) * 22;
      const clamp = (v, m) => Math.max(-m, Math.min(m, v));
      if (this.state === 'patrol') {
        this.facing = this.dir; this.vx = this.dir * d.speed; this.vy = clamp((this.homeY + bob - cy) * 2, 80);
        if (world.get(Math.floor((cx + this.dir * 20) / T), Math.floor(cy / T)) === 1 || Math.abs(cx - this.home) > 160) this.dir = -this.dir;
        if (sees) this.state = 'chase';
      } else if (this.state === 'chase') {
        if (!alive || inSafe || dist > d.aggro * 1.6) this.state = 'patrol';
        this.facing = px > cx ? 1 : -1;
        if (d.ranged) {                                                              // дальник: держит дистанцию, стреляет с высоты
          const sx = cx < px ? -1 : 1;
          this.vx = clamp((px + sx * d.ranged.keep - cx) * 2, d.chaseSpeed); this.vy = clamp((py - 90 + bob - cy) * 2, d.chaseSpeed);
          if (alive && Math.hypot(px - cx, py - cy) <= d.range && this.cd <= 0 && this.clearShot(world, cx, cy, px, py)) { this.state = 'windup'; this.t = 0; this.vx = this.vy = 0; }
        } else {
          this.vx = clamp((px - this.facing * 70 - cx) * 2, d.chaseSpeed); this.vy = clamp((py - 80 + bob - cy) * 2, d.chaseSpeed);
          if (alive && Math.hypot(px - cx, py - cy) <= d.range && this.cd <= 0) { this.state = 'windup'; this.t = 0; this.vx = this.vy = 0; }
        }
      } else if (this.state === 'windup') {
        this.facing = px > cx ? 1 : -1; this.vx = Math.sin(this.t * 60) * 30; this.vy = 0;
        if (this.t >= d.windup && d.ranged) {                                        // выстрел
          this.state = 'attack'; this.t = 0; this.hitDone = true; this.vx = this.vy = 0;
          const tx = px + player.vx * 0.25, L = Math.hypot(tx - cx, py - cy) || 1;
          this.pendingShot = { x: cx + this.facing * 14, y: cy + 4, vx: (tx - cx) / L * d.ranged.speed, vy: (py - cy) / L * d.ranged.speed, dmg: d.dmg };
        } else if (this.t >= d.windup) {
          const L = Math.hypot(px - cx, py - cy) || 1; this.state = 'attack'; this.t = 0; this.hitDone = false; this.vx = (px - cx) / L * d.lunge; this.vy = (py - cy) / L * d.lunge;
        }
      } else if (this.state === 'attack') {
        if (this.t >= d.active) { this.state = 'recover'; this.t = 0; }
      } else if (this.state === 'recover') {
        this.vx *= 0.9; this.vy = d.ranged ? 0 : -70; if (this.t >= d.recover) { this.state = 'chase'; this.cd = d.ranged ? d.ranged.cd : 0.8; }
      } else if (this.state === 'stagger') {
        this.vx *= 0.92; this.vy *= 0.92; if (this.t >= 0.45) { this.state = 'chase'; this.cd = 0.5; }
      }
      if (this.slow > 0) { this.slow -= dt; this.vx *= 0.55; this.vy *= 0.55; }
      DF.Physics.move(this, world, dt);
      if (world.safeX && this.x + this.w > world.safeX) { this.x = world.safeX - this.w; this.vx = Math.min(this.vx, 0); this.dir = -1; }
    }
    update(dt, world, player) {
      const d = this.d; this.hurtFlash = Math.max(0, this.hurtFlash - dt); this.cd -= dt;
      if (!this.d.flying || (this.dead && !this.d.noFall)) this.vy = Math.min(this.vy + C.GRAVITY * dt, C.MAX_FALL);
      if (!this.dead && this.burn > 0) {                                             // горение: 4 урона каждые 0.5 с
        this.burn -= dt; this.burnT = (this.burnT || 0) + dt;
        if (this.burnT >= 0.5) { this.burnT = 0; this.hp -= 4; this.hurtFlash = 0.08; if (this.hp <= 0) { this.dead = true; this.state = 'dead'; } }
      }
      if (this.dead) { this.deadT += dt; this.vx *= 0.9; DF.Physics.move(this, world, dt); return; }
      const dx = player.x + player.w / 2 - (this.x + this.w / 2), dy = player.y + player.h / 2 - (this.y + this.h / 2), dist = Math.abs(dx);
      const alive = player.state !== 'dead', inSafe = !!world.safeX && player.x + player.w / 2 > world.safeX, sees = alive && !inSafe && dist < d.aggro && Math.abs(dy) < (d.flying ? 240 : 90);
      this.t += dt;
      if (d.flying) { this.fly(dt, world, player, dist, sees, alive, inSafe); return; }
      if (this.state === 'patrol') {
        this.facing = this.dir; this.vx = this.dir * d.speed;
        if (this.blocked(world) || Math.abs(this.x - this.home) > 170) { this.dir = -this.dir; this.facing = this.dir; this.vx = this.dir * d.speed; this.home += (this.home - this.x) * 0; }
        if (sees) this.state = 'chase';
      } else if (this.state === 'chase') {
        if (!alive || inSafe || dist > d.aggro * 1.6) this.state = 'patrol';
        this.facing = dx > 0 ? 1 : -1;
        if (dist > d.range * 0.8 && !this.blocked(world)) this.vx = this.facing * d.chaseSpeed; else this.vx = 0;
        if (alive && dist <= d.range && Math.abs(dy) < 60 && this.cd <= 0) { this.state = 'windup'; this.t = 0; this.vx = 0; }
      } else if (this.state === 'windup') {
        this.vx = 0; if (this.t >= d.windup) { this.state = 'attack'; this.t = 0; this.hitDone = false; this.vx = this.facing * d.lunge; }
      } else if (this.state === 'attack') {
        if (this.t >= d.active) { this.state = 'recover'; this.t = 0; }
      } else if (this.state === 'recover') {
        this.vx *= 0.88; if (this.t >= d.recover) { this.state = 'chase'; this.cd = 0.4; }
      } else if (this.state === 'stagger') {
        this.vx *= 0.92; if (this.t >= 0.45) { this.state = 'chase'; this.cd = 0.3; }
      }
      if (this.slow > 0) { this.slow -= dt; this.vx *= 0.55; }                       // ледяное замедление
      DF.Physics.move(this, world, dt);
      if (world.safeX && this.x + this.w > world.safeX) { this.x = world.safeX - this.w; this.vx = Math.min(this.vx, 0); this.dir = -1; }
    }
  }
  DF.Enemy = Enemy;
})();
