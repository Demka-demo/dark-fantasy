// Единый цикл requestAnimationFrame: фиксированный шаг логики + отдельная отрисовка.
// Здесь же правила «как в Dark Souls» (костры, смерть, души, респавн, сохранение) и лавка торговца.
// Режимы: play — игра, shop — окно торговца, dead — экран смерти.
(function () {
  const DF = window.DF, C = DF.CONFIG, PRESS = ['jump', 'light', 'heavy', 'special', 'roll', 'heal', 'ability'];
  class Game {
    constructor(canvas) {
      this.input = new DF.Input(); this.renderer = new DF.Renderer(canvas); this.camera = new DF.Camera();
      this.world = DF.World.createLevel(1); this.player = new DF.Player(0, 0); this.menu = new DF.Menu(this); this.dialogue = new DF.Dialogue(this);
      this.mode = 'menu'; this.deadT = 0; this.fade = 1; this.banner = { text: '', t: 0 }; this.shake = 0; this.hitstop = 0; this.time = 0;
      this.shop = { sel: 0, view: 'list', offers: [], msg: '', line: '' }; this.trader = { t: 0, approveT: 0 }; this.fx = []; this.parts = []; this.queue = {};
      this.debug = false; this.fps = 0; this.acc = 0; this.last = 0; this._fpsT = 0; this._fpsN = 0;
      this.loadSave(); this.menu.open();
      this.loop = t => {
        const dt = Math.min((t - this.last) / 1000, 0.1); this.last = t;
        this.update(dt); this.renderer.draw(this);
        this._fpsT += dt; this._fpsN++;
        if (this._fpsT >= 0.5) { this.fps = Math.round(this._fpsN / this._fpsT); this._fpsT = 0; this._fpsN = 0; }
        requestAnimationFrame(this.loop);
      };
    }
    // Состояние из сохранения (или чистое, если сохранения нет): игрок у последнего костра, враги расставлены заново.
    loadSave() {
      const sv = DF.Save.load() || {};
      this.bonfireId = sv.bonfire || null; this.lit = new Set(sv.lit || []); this.souls = sv.souls || 0; this.bloodstain = sv.blood || null;
      this.owned = new Set(sv.weapons || ['wood']); this.weapon = this.owned.has(sv.weapon) ? sv.weapon : 'wood';
      this.emeralds = sv.emeralds || 0; this.ability = DF.DATA.ABILITIES[sv.ability] ? sv.ability : null;
      this.met = sv.met || {}; this.enemyShots = [];
      this.abilityCd = 0; this.buffT = 0; this.projectiles = []; this.wasSafe = false; this.vfx = new DF.Effects(); this.animator = new DF.Animator();
      this.player.reset(this.spawnPoint()); this.spawnEnemies(); this.camera.snap(this.player, this.world);
    }
    startPlay() { this.mode = 'play'; this.fade = 1; this.queue = {}; }
    newGame() { DF.Save.clear(); this.loadSave(); this.startPlay(); }
    start() { requestAnimationFrame(t => { this.last = t; this.loop(t); }); }
    spawnPoint() {
      const b = this.world.bonfires.find(x => x.id === this.bonfireId);
      return b ? { x: b.x - C.PLAYER.W / 2, y: b.y - C.PLAYER.H } : { x: this.world.spawn.x, y: this.world.spawn.y };
    }
    spawnEnemies() { this.enemies = this.world.spawns.map(s => new DF.Enemy(s.type, s.x, s.y)); }
    nearBonfire() {
      const p = this.player;
      return this.world.bonfires.find(b => Math.abs(p.x + p.w / 2 - b.x) < 40 && Math.abs(p.y + p.h - b.y) < 24) || null;
    }
    nearNpc() {
      const p = this.player;
      return this.world.npcs.find(n => Math.abs(p.x + p.w / 2 - n.x) < 60 && Math.abs(p.y + p.h - n.y) < 24) || null;
    }
    persist() { DF.Save.write({ bonfire: this.bonfireId, lit: [...this.lit], souls: this.souls, blood: this.bloodstain, weapons: [...this.owned], weapon: this.weapon, emeralds: this.emeralds, ability: this.ability, met: this.met }); }
    say(text, t) { this.banner = { text, t: t || 2.2 }; }
    rest(b) {
      const first = !this.lit.has(b.id); this.lit.add(b.id); this.bonfireId = b.id;
      const p = this.player; p.hp = p.maxHp; p.sta = p.maxSta; p.estus = p.estusMax;
      this.spawnEnemies(); this.fade = 1; this.say(first ? 'КОСТЁР ЗАЖЖЁН' : b.name); this.persist();
    }
    dmgMult() { return this.buffT > 0 ? 1.3 : 1; }
    reward(e) {                                                                      // души и изумруды за убийство (в том числе от горения)
      e.rewarded = true; this.souls += e.d.souls; this.addFx(e.x + e.w / 2, e.y - 28, `+${e.d.souls}`, '#e8d9a8');
      const em = e.d.emerald;
      if (em && Math.random() < em.chance) { this.emeralds += em.n; this.addFx(e.x + e.w / 2, e.y - 46, `+${em.n} изумруд`, '#6fe0a0'); }
      this.persist();
    }
    // Снаряды врагов-дальников: бьют игрока, гаснут о стены; удар игрока сбивает их; перекат даёт пройти насквозь.
    updateShots(dt) {
      const p = this.player, T = C.TILE;
      for (const s of this.enemyShots) {
        s.x += s.vx * dt; s.y += s.vy * dt; s.t += dt;
        if (this.world.get(Math.floor(s.x / T), Math.floor(s.y / T)) === 1) { s.dead = true; this.sparks(s.x, s.y, ['#ffb347', '#ff6a1a'], 5, 3, true); }
        if (!s.dead && p.state !== 'dead' && s.x > p.x - 6 && s.x < p.x + p.w + 6 && s.y > p.y && s.y < p.y + p.h && p.hurt(s.dmg, Math.sign(s.vx) || 1, 200)) { s.dead = true; this.onPlayerHit({ d: { dmg: s.dmg } }); }
        if (Math.random() < dt * 50) this.parts.push({ x: s.x, y: s.y, vx: (Math.random() - 0.5) * 20, vy: (Math.random() - 0.5) * 20, g: 0, t: 0.25, size: 3, glow: true, color: '#ff8a2a' });
      }
      this.enemyShots = this.enemyShots.filter(s => !s.dead && s.t < 4);
    }
    // Лава: игрок получает 30 урона и подбрасывается вверх; наземные враги в ней гибнут.
    lavaCheck() {
      const p = this.player, T = C.TILE, y = Math.floor((p.y + p.h - 4) / T);
      if (p.state !== 'dead') for (let tx = Math.floor((p.x + 4) / T); tx <= Math.floor((p.x + p.w - 5) / T); tx++) if (this.world.get(tx, y) === 3) {
        if (p.hurt(30, 0, 0)) { p.vy = -650; p.vx *= 0.3; this.sparks(p.x + p.w / 2, p.y + p.h, ['#ff9a2a', '#ffd25a'], 14, 3, true); this.shake = 8; this.addFx(p.x + p.w / 2, p.y - 10, '30', '#ff9a2a'); }
        break;
      }
      for (const e of this.enemies) if (!e.dead && !e.d.flying && this.world.get(Math.floor((e.x + e.w / 2) / T), Math.floor((e.y + e.h - 2) / T)) === 3) {
        e.dead = true; e.state = 'dead'; e.rewarded = true; this.sparks(e.x + e.w / 2, e.y + e.h, ['#ff9a2a', '#ffd25a'], 10, 3, true);
      }
    }
    // Активные способности клинка (клавиша R). Пассивные работают в onEnemyHit.
    useAbility() {
      const ab = DF.DATA.ABILITIES[this.ability], p = this.player;
      if (!ab || ab.type !== 'active' || this.abilityCd > 0 || p.state === 'dead') return;
      this.abilityCd = ab.cd;
      if (this.ability === 'blink') {
        const T = C.TILE, fits = x => { for (let ty = Math.floor(p.y / T); ty <= Math.floor((p.y + p.h - 1) / T); ty++) for (let tx = Math.floor(x / T); tx <= Math.floor((x + p.w - 1) / T); tx++) if (this.world.get(tx, ty) === 1) return false; return true; };
        this.sparks(p.x + p.w / 2, p.y + p.h / 2, ['#7fc8ff', '#ffffff'], 10, 3, true);
        for (let d = 0; d < 150; d += 4) { if (!fits(p.x + p.facing * 4)) break; p.x += p.facing * 4; }
        p.invuln = Math.max(p.invuln, 0.35); this.sparks(p.x + p.w / 2, p.y + p.h / 2, ['#7fc8ff', '#ffffff'], 10, 3, true);
      } else if (this.ability === 'wave') {
        this.projectiles.push({ x: p.x + p.w / 2 + p.facing * 20, y: p.y + p.h * 0.5, vx: p.facing * 520, facing: p.facing, t: 0, hit: new Set(), dmg: Math.round(30 * DF.DATA.WEAPONS[this.weapon].mult * this.dmgMult()) });
      } else if (this.ability === 'cry') { this.buffT = 8; this.addFx(p.x + p.w / 2, p.y - 30, 'БОЕВОЙ КЛИЧ', '#ff7a5a'); this.shake = 6; }
    }
    updateProjectiles(dt) {
      for (const pr of this.projectiles) {
        pr.x += pr.vx * dt; pr.t += dt;
        if (this.world.get(Math.floor(pr.x / C.TILE), Math.floor(pr.y / C.TILE)) === 1) pr.t = 9;
        for (const e of this.enemies) {
          if (e.dead || pr.hit.has(e) || Math.abs(e.x + e.w / 2 - pr.x) > e.w / 2 + 22 || pr.y < e.y - 10 || pr.y > e.y + e.h + 10) continue;
          pr.hit.add(e); const def = { damage: pr.dmg, knock: 260, stagger: 30, kind: 'light' };
          this.onEnemyHit(e, def, pr.facing, e.hurt(def, pr.facing));
        }
      }
      this.projectiles = this.projectiles.filter(pr => pr.t < 0.9);
    }
    addFx(x, y, text, color) { this.fx.push({ x, y, text, color, t: 1.0 }); }
    sparks(x, y, color, n, size, glow) {
      for (let i = 0; i < n; i++) this.parts.push({ x, y, vx: (Math.random() - 0.5) * 260, vy: -Math.random() * 220, t: 0.35 + Math.random() * 0.2, size: size || 3, glow: !!glow,
        color: Array.isArray(color) ? color[Math.floor(Math.random() * color.length)] : color });
    }
    onEnemyHit(e, def, dir, result) {
      this.addFx(e.x + e.w / 2, e.y - 10, String(def.damage), '#fff');
      const h = DF.DATA.WEAPONS[this.weapon].fx.hit; this.sparks(e.x + e.w / 2, e.y + e.h / 2, h.colors, h.n, h.size, h.glow);
      this.hitstop = result === 'kill' ? 0.1 : 0.05; this.shake = Math.max(this.shake, def.kind === 'heavy' ? 7 : 3);
      if (result !== 'kill') { if (this.ability === 'burn') e.burn = 3; if (this.ability === 'frost') e.slow = 2; }
      if (this.ability === 'vamp') {
        const hl = Math.max(1, Math.round(def.damage * 0.15)), pl = this.player; pl.hp = Math.min(pl.maxHp, pl.hp + hl); this.addFx(pl.x + pl.w / 2, pl.y - 24, `+${hl}`, '#6fe08a');
      }
    }
    onPlayerHit(e) {
      const p = this.player; this.sparks(p.x + p.w / 2, p.y + p.h / 2, '#c33', 8); this.hitstop = 0.07; this.shake = 8;
      this.addFx(p.x + p.w / 2, p.y - 10, String(e.d.dmg), '#ff6060');
    }
    // Росчерк меча: один раз в начале активной фазы атаки; вид зависит от оружия и вида удара.
    spawnSlash() {
      const p = this.player, a = p.atk; if (p.state !== 'attack' || a.phase !== 'active' || a.vfx) return;
      a.vfx = true; const v = DF.DATA.WEAPONS[this.weapon].vfx;
      const key = a.act === 'light' ? (a.idx === 2 ? v.finish : v.light) : a.act === 'heavy' ? v.heavy : v.special;
      const tr = DF.DATA.WEAPONS[this.weapon].fx.trail;                                  // частицы вдоль дуги удара
      for (let k = 0; k < tr.n; k++) {
        const ang = -1.1 + Math.random() * 2.2, r = 30 + Math.random() * 32;
        this.parts.push({ x: p.x + p.w / 2 + p.facing * Math.cos(ang) * r, y: p.y + p.h * 0.45 + Math.sin(ang) * r, vx: p.facing * (30 + Math.random() * 130), vy: (Math.random() - 0.5) * 120,
          t: 0.3 + Math.random() * 0.3, size: tr.size, glow: tr.glow, color: tr.colors[Math.floor(Math.random() * tr.colors.length)] });
      }
      this.vfx.spawn(key, p.x + p.w / 2 + p.facing * v.ox, p.y + p.h * 0.5 + v.oy, { flip: p.facing, scale: v.scale * (a.act === 'heavy' ? 1.15 : 1), alpha: v.alpha });
    }
    die() {
      const p = this.player, T = C.TILE, inLava = this.world.get(Math.floor((p.x + p.w / 2) / T), Math.floor((p.y + p.h - 4) / T)) === 3;
      const pos = p.y > this.world.pxH || inLava ? p.safe : { x: p.x, y: p.y };
      if (this.souls > 0) this.bloodstain = { x: pos.x + p.w / 2, y: pos.y + p.h, souls: this.souls };   // новое пятно заменяет старое
      this.souls = 0; this.mode = 'dead'; this.deadT = 0; this.shake = 10; this.persist();
    }
    respawn() {
      const sp = this.spawnPoint(); this.player.reset(sp); this.animator = new DF.Animator(); this.vfx = new DF.Effects();
      this.projectiles = []; this.buffT = 0; this.abilityCd = 0;
      this.spawnEnemies(); this.mode = 'play'; this.fade = 1; this.camera.snap(this.player, this.world);
    }
    // --- лавка торговца
    openShop() { this.mode = 'shop'; this.player.vx = 0; this.shop = { sel: 0, view: 'list', offers: [], msg: '', line: DF.DATA.TRADER.lines[Math.floor(Math.random() * DF.DATA.TRADER.lines.length)] }; }
    closeShop() { this.mode = 'play'; this.queue = {}; }
    openOffers() {                                                                   // 3 случайные способности на выбор
      const pool = Object.keys(DF.DATA.ABILITIES).filter(a => a !== this.ability).sort(() => Math.random() - 0.5);
      this.shop.offers = pool.slice(0, DF.DATA.ENCHANT.offers); this.shop.view = 'offers'; this.shop.sel = 0; this.shop.msg = '';
    }
    chooseEnchant(id) {
      const E = DF.DATA.ENCHANT, cost = this.ability ? E.recost : E.cost, sh = this.shop;
      if (this.emeralds < cost) { sh.msg = 'Не хватает изумрудов'; return; }
      this.emeralds -= cost; this.ability = id; this.abilityCd = 0; this.trader.approveT = 1.2;
      sh.view = 'list'; sh.sel = DF.DATA.SHOP.length - 1; sh.msg = `Клинок зачарован: ${DF.DATA.ABILITIES[id].name}`; this.persist();
    }
    buy(id) {
      if (id === 'enchant') { this.openOffers(); return; }
      const w = DF.DATA.WEAPONS[id], sh = this.shop;
      if (this.owned.has(id)) { this.weapon = id; sh.msg = `Экипировано: ${w.name}`; }
      else if (this.souls >= w.price) { this.souls -= w.price; this.owned.add(id); this.weapon = id; this.trader.approveT = 1.2; sh.msg = `Куплено: ${w.name}`; }
      else sh.msg = 'Не хватает душ';
      this.persist();
    }
    shopInput(i) {
      const sh = this.shop, offers = sh.view === 'offers', list = offers ? sh.offers : DF.DATA.SHOP;
      if (i.pressed('down')) sh.sel = (sh.sel + 1) % list.length;
      if (i.pressed('jump')) sh.sel = (sh.sel + list.length - 1) % list.length;
      if (i.pressed('confirm')) { if (offers) this.chooseEnchant(list[sh.sel]); else this.buy(list[sh.sel]); }
      if (i.pressed('cancel') || i.pressed('interact')) { if (offers) { sh.view = 'list'; sh.sel = DF.DATA.SHOP.length - 1; sh.msg = ''; } else this.closeShop(); }
    }
    update(dt) {
      const i = this.input;
      if (i.pressed('debug')) this.debug = !this.debug;
      if (i.pressed('wipe')) { DF.Save.clear(); location.reload(); return; }
      if (this.mode === 'menu' || this.mode === 'pause') {                              // меню и пауза: логика мира стоит
        this.queue = {}; this.menu.update(dt, i); this.time += dt; this.fade = Math.max(0, this.fade - dt * 1.4); i.endFrame(); return;
      }
      for (const a of PRESS) if (i.pressed(a)) this.queue[a] = true;
      let sim = dt; if (this.hitstop > 0) { this.hitstop -= dt; sim = 0; }
      const cmd = { left: i.down('left'), right: i.down('right'), down: i.down('down'), jumpHeld: i.down('jump'), jumpPressed: false, press: {} };
      const idle = { press: {} }, p = this.player;
      for (this.acc += sim; this.acc >= C.STEP; this.acc -= C.STEP) {
        if (this.mode === 'play') {
          cmd.jumpPressed = !!this.queue.jump; cmd.press = this.queue; this.queue = {};
          p.update(C.STEP, cmd, this.world); this.spawnSlash(); if (cmd.press.ability) this.useAbility();
          for (const e of this.enemies) { e.update(C.STEP, this.world, p); if (e.pendingShot) { this.enemyShots.push(Object.assign({ t: 0 }, e.pendingShot)); e.pendingShot = null; } }
          DF.Combat.update(this); this.updateProjectiles(C.STEP); this.updateShots(C.STEP); this.lavaCheck();
          for (const e of this.enemies) if (e.dead && !e.rewarded) this.reward(e);
          if (p.hp <= 0) this.die();
        } else { this.queue = {}; p.update(C.STEP, idle, this.world); }
      }
      if (this.mode === 'play') {
        if (i.pressed('cancel')) { this.mode = 'pause'; this.menu.openPause(); }
        const nb = this.nearBonfire(), nn = this.nearNpc();
        if (i.pressed('interact') && p.state === 'move' && p.onGround) { if (nb) this.rest(nb); else if (nn) this.dialogue.open('trader'); }
        const bs = this.bloodstain;
        if (bs && Math.abs(p.x + p.w / 2 - bs.x) < 28 && Math.abs(p.y + p.h - bs.y) < 40) {
          this.souls += bs.souls; this.addFx(bs.x, bs.y - 30, `+${bs.souls}`, '#e8d9a8'); this.bloodstain = null; this.persist(); this.say('ДУШИ ВОЗВРАЩЕНЫ', 1.8);
        }
        const safe = p.x > this.world.safeX; if (safe && !this.wasSafe) this.say('БЕЗОПАСНАЯ ЗОНА', 2.6); this.wasSafe = safe;
        this.enemies = this.enemies.filter(e => !(e.dead && e.deadT > 1));
      } else if (this.mode === 'shop') this.shopInput(i);
      else if (this.mode === 'dialog') this.dialogue.update(dt, i);
      else { this.deadT += dt; if (this.deadT > 3.6) this.respawn(); }
      this.time += dt; this.trader.t += dt; this.trader.approveT = Math.max(0, this.trader.approveT - dt);
      this.fade = Math.max(0, this.fade - dt * 1.4); this.banner.t -= dt; this.shake = Math.max(0, this.shake - dt * 30);
      for (const f of this.fx) { f.y -= 28 * dt; f.t -= dt; } this.fx = this.fx.filter(f => f.t > 0);
      const lt = this.world.lavaTops;                                                 // искры над лавой рядом с камерой
      for (let k = 0; k < 2 && lt.length && Math.random() < dt * 14; k++) {
        const q = lt[Math.floor(Math.random() * lt.length)], qx = q.x * C.TILE + Math.random() * C.TILE;
        if (qx > this.camera.x - 40 && qx < this.camera.x + C.VIEW_W + 40) this.parts.push({ x: qx, y: q.y * C.TILE, vx: (Math.random() - 0.5) * 30, vy: -(40 + Math.random() * 80), g: -10, t: 0.9 + Math.random() * 0.8, size: 3, glow: true, color: '#ff9a3a' });
      }
      for (const q of this.parts) { q.x += q.vx * dt; q.y += q.vy * dt; q.vy += (q.g === undefined ? 700 : q.g) * dt; q.t -= dt; } this.parts = this.parts.filter(q => q.t > 0);
      this.abilityCd = Math.max(0, this.abilityCd - dt); this.buffT = Math.max(0, this.buffT - dt);
      for (const e of this.enemies) if (!e.dead) {                                  // огоньки и льдинки на заражённых врагах
        if (e.burn > 0 && Math.random() < dt * 8) this.sparks(e.x + e.w / 2, e.y + e.h * 0.5, ['#ff8a2a', '#ffd35a'], 1, 3, true);
        if (e.slow > 0 && Math.random() < dt * 6) this.sparks(e.x + e.w / 2, e.y + e.h * 0.5, ['#9fd8ff', '#ffffff'], 1, 2, true);
      }
      this.vfx.update(dt); this.animator.update(dt, p); this.camera.update(dt, p, this.world); i.endFrame();
    }
  }
  DF.Game = Game;
})();
