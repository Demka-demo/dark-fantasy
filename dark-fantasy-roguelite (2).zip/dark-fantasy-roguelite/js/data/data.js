// Единый источник характеристик атак, переката и врагов. Баланс правится только здесь.
(function () {
  const DF = window.DF;
  DF.DATA = {
    ATTACKS: {
      // kind — вид атаки; stagger сравнивается с poise врага: если не меньше — враг сбит с атаки.
      light: [   // лёгкое комбо из трёх ударов (J)
        { kind: 'light', stamina: 10, windup: 0.07, active: 0.09, recover: 0.16, damage: 16, anim: 'attack3', w: 50, h: 44, knock: 130, stagger: 10, lunge: 80 },
        { kind: 'light', stamina: 10, windup: 0.07, active: 0.09, recover: 0.16, damage: 18, anim: 'runattack', w: 50, h: 44, knock: 150, stagger: 10, lunge: 90 },
        { kind: 'light', stamina: 14, windup: 0.10, active: 0.11, recover: 0.30, damage: 26, anim: 'attack2', w: 58, h: 50, knock: 300, stagger: 25, lunge: 140 }
      ],
      heavy:   { kind: 'heavy',   stamina: 28, windup: 0.42, active: 0.12, recover: 0.42, damage: 48, anim: 'attack1', w: 64, h: 56, knock: 420, stagger: 45, lunge: 200 },  // K
      special: { kind: 'special', stamina: 22, windup: 0.12, active: 0.10, recover: 0.36, damage: 8, anim: 'defend',  w: 44, h: 50, knock: 560, stagger: 60, lunge: 60 }    // L: удар щитом
    },
    // Оружие: mult — множитель урона; vfx — росчерки (ключи из CONFIG.VFX), ox/oy — смещение эффекта от центра тела.
    WEAPONS: {
      wood: { name: 'Деревянный меч', mult: 0.75, icon: 'sword_wood', desc: 'Тренировочный. Слабый, но свой.',
              vfx: { light: 'slash3_c4', finish: 'slash1_c4', heavy: 'slash1_c4', special: 'slash3_c4', scale: 0.5, alpha: 0.8, ox: 34, oy: -6 },
              fx: { hit: { colors: ['#c9a06a', '#8a6a40', '#e8d2a0'], n: 6, size: 3, glow: false }, trail: { colors: ['#b08a5a', '#8a6a40'], n: 4, size: 2, glow: false } } },
      steel: { name: 'Лазурный клинок', mult: 1.5, price: 120, icon: 'sword_steel', desc: 'Больше урона и яркие росчерки.',
               vfx: { light: 'slash3_c5', finish: 'slash2_c5', heavy: 'slash2_c5', special: 'slash1_c5', scale: 0.8, alpha: 1, ox: 36, oy: -6 },
               fx: { hit: { colors: ['#bfe6ff', '#ffffff', '#4aa8ff'], n: 14, size: 3, glow: true }, trail: { colors: ['#7fc8ff', '#ffffff', '#4aa8ff'], n: 18, size: 3, glow: true }, aura: 'drop-shadow(0 0 3px #5cb8ff)' } }
    },
    SHOP: ['wood', 'steel', 'enchant'],
    // Зачарование клинка за изумруды (как у нейтральных предметов): выбор 1 из 3 способностей. active — на клавише R с перезарядкой, passive — всегда.
    ENCHANT: { cost: 4, recost: 6, offers: 3 },
    ABILITIES: {
      blink: { name: 'Теневой шаг', type: 'active', cd: 6, desc: 'R: рывок вперёд и миг неуязвимости.' },
      wave:  { name: 'Волна клинка', type: 'active', cd: 8, desc: 'R: энергетическая волна летит вперёд и ранит врагов.' },
      cry:   { name: 'Боевой клич', type: 'active', cd: 20, desc: 'R: +30% к урону на 8 секунд.' },
      vamp:  { name: 'Кровавая жажда', type: 'passive', desc: 'Удары лечат на 15% нанесённого урона.' },
      burn:  { name: 'Тлеющий клинок', type: 'passive', desc: 'Враги горят: 4 урона каждые 0.5 с, 3 секунды.' },
      frost: { name: 'Ледяное касание', type: 'passive', desc: 'Удары замедляют врагов на 2 секунды.' }
    },
    TRADER: { name: 'Странствующий торговец', lines: ['Души — хорошая монета, путник.', 'Деревяшкой далеко не уйдёшь...', 'Здесь тихо. Туман не пускает тварей.', 'Выбирай клинок. Не торопись.'] },
    // Диалоги (тексты временные — замените на канонические). who: 'hero' | 'npc'; emo — портрет героя: calm, talk, sadness, aggression, special, smile.
    HERO_NAME: 'Рыцарь',
    DIALOGUE: {
      trader: {
        name: 'Странствующий торговец',
        first: [
          { who: 'npc', text: 'Не часто сюда доходят живыми. Входи, путник. Туман здесь не властен.' },
          { who: 'hero', emo: 'calm', text: 'Ты торгуешь? Здесь, посреди этого кошмара?' },
          { who: 'npc', text: 'У проклятых земель своя монета: души и изумруды. Я беру любую.' },
          { who: 'hero', emo: 'sadness', text: 'У меня только деревянный меч и пара душ.' },
          { who: 'npc', text: 'Деревяшка тоже клинок. А за изумруды можно вдохнуть в сталь силу.' },
          { who: 'hero', emo: 'smile', text: 'Покажи, что у тебя есть.' }
        ],
        again: [{ who: 'npc', text: 'Снова ты. Живой. Хороший знак. Чем могу помочь?' }],
        choices: [{ id: 'trade', label: 'Посмотреть товары' }, { id: 'leave', label: 'Уйти' }],
        farewell: [{ who: 'npc', text: 'Тропы здесь недобрые. Возвращайся целым.' }]
      }
    },
    ROLL: { stamina: 18, time: 0.34, iframes: [0.04, 0.26], speed: 430 },
    ENEMIES: {
      hollow: { name: 'Полый воин', w: 24, h: 56, skin: 'knight2', scale: 1, atkAnim: 'attack1', hp: 60, speed: 60, chaseSpeed: 105, aggro: 230, range: 56, poise: 12, dmg: 18, windup: 0.55, active: 0.12, recover: 0.7, lunge: 60, hitW: 58, hitH: 52, knock: 240, souls: 40, emerald: { chance: 0.35, n: 1 }, color: '#7d6a58', eye: '#ff5a3c' },
      wolf:   { name: 'Оборотень', w: 44, h: 48, skin: 'werewolf', scale: 1, sheet: { ax: 52, ay: 128 }, atkAnim: 'attack',
                anims: { idle: { frames: 4, fps: 6 }, walk: { frames: 4, fps: 8 }, run: { frames: 4, fps: 12 }, attack: { frames: 4, fps: 10, hit: 2 }, hurt: { frames: 3, fps: 8 }, dead: { frames: 4, fps: 8 }, howl: { frames: 3, fps: 6 } },
                hp: 45, speed: 80, chaseSpeed: 190, aggro: 300, range: 80, poise: 8, dmg: 16, windup: 0.4, active: 0.22, recover: 0.8, lunge: 420, hitW: 56, hitH: 46, knock: 220, souls: 35, emerald: { chance: 0.5, n: 1 }, color: '#6b4a32', eye: '#ff3a5a' },
      bat:    { name: 'Летучий страж', w: 30, h: 24, flying: true, hp: 26, speed: 70, chaseSpeed: 140, aggro: 300, range: 170, poise: 6, dmg: 14, windup: 0.55, active: 0.5, recover: 1.0, lunge: 420, hitW: 30, hitH: 24, knock: 200, souls: 25, emerald: { chance: 0.3, n: 1 }, color: '#3a3350', eye: '#ff4040' },
      demon:  { name: 'Летающий демон', w: 38, h: 38, flying: true, noFall: true, skin: 'demon', scale: 1, sheet: { ax: 40, ay: 35, fw: 81, fh: 71 }, atkAnim: 'attack',
                anims: { idle: { frames: 4, fps: 6 }, walk: { frames: 4, fps: 9 }, attack: { frames: 8, fps: 10, hit: 4 }, hurt: { frames: 4, fps: 10 }, dead: { frames: 7, fps: 10 } },
                ranged: { speed: 300, keep: 240, cd: 2.0 }, hp: 30, speed: 60, chaseSpeed: 120, aggro: 380, range: 420, poise: 6, dmg: 12, windup: 0.6, active: 0.2, recover: 0.8, lunge: 0, hitW: 38, hitH: 38,
                knock: 220, souls: 30, emerald: { chance: 0.4, n: 1 }, color: '#8a2a2a', eye: '#ffd23c' },
      brute:  { name: 'Палач', w: 34, h: 76, skin: 'knight3', scale: 1.25, atkAnim: 'attack1', hp: 180, speed: 40, chaseSpeed: 70, aggro: 200, range: 84, poise: 50, dmg: 42, windup: 0.85, active: 0.14, recover: 1.0, lunge: 40, hitW: 88, hitH: 70, knock: 520, souls: 150, emerald: { chance: 1, n: 3 }, color: '#5b3a3a', eye: '#ff2a2a' }
    }
  };
})();
