// Одноразовые боевые эффекты. Росчерк привязан к игроку и синхронизирован с длительностью конкретного взмаха.
(function () {
  const DF = window.DF, C = DF.CONFIG;
  class Effects {
    constructor() { this.list = []; }
    spawn(key, x, y, o) {
      const spec = C.VFX[key]; if (!spec || !DF.Assets.get('vfx_' + key)) return;
      const opts = o || {};
      this.list.push({
        key, spec, x, y, t: 0,
        flip: opts.flip || 1,
        facing: opts.flip || 1,
        scale: opts.scale || 1,
        rot: opts.rot || 0,
        rotStart: opts.rotStart === undefined ? (opts.rot || 0) : opts.rotStart,
        rotEnd: opts.rotEnd === undefined ? (opts.rot || 0) : opts.rotEnd,
        alpha: opts.alpha === undefined ? 1 : opts.alpha,
        duration: Math.max(0.06, opts.duration || spec.frames / spec.fps),
        follow: opts.follow || null,
        attack: opts.attack || null,
        offsetXStart: opts.offsetXStart || 0,
        offsetXEnd: opts.offsetXEnd === undefined ? (opts.offsetXStart || 0) : opts.offsetXEnd,
        offsetYStart: opts.offsetYStart || 0,
        offsetYEnd: opts.offsetYEnd === undefined ? (opts.offsetYStart || 0) : opts.offsetYEnd,
        scaleStart: opts.scaleStart || opts.scale || 1,
        scaleEnd: opts.scaleEnd === undefined ? (opts.scaleStart || opts.scale || 1) : opts.scaleEnd,
        lastX: x, lastY: y
      });
    }
    update(dt) {
      for (const e of this.list) {
        e.t += dt;
        // Once a new attack starts, freeze the old trail where it last was rather than dragging it along.
        if (e.follow && e.attack && e.follow.atk !== e.attack) e.follow = null;
        if (e.follow) {
          const p = e.follow, k = Math.min(1, e.t / e.duration), eased = k * k * (3 - 2 * k);
          e.x = p.x + p.w / 2 + e.facing * (e.offsetXStart + (e.offsetXEnd - e.offsetXStart) * eased);
          e.y = p.y + e.offsetYStart + (e.offsetYEnd - e.offsetYStart) * eased;
          e.lastX = e.x; e.lastY = e.y;
        } else { e.x = e.lastX; e.y = e.lastY; }
      }
      this.list = this.list.filter(e => e.t < e.duration);
    }
    draw(c) {
      for (const e of this.list) {
        const progress = Math.max(0, Math.min(1, e.t / e.duration));
        const eased = progress * progress * (3 - 2 * progress);
        // Весь спрайт-лист проигрывается за время удара, а не после того, как меч уже остановился.
        const f = Math.min(e.spec.frames - 1, Math.floor(progress * e.spec.frames));
        const rot = e.rotStart + (e.rotEnd - e.rotStart) * eased;
        const scale = e.scaleStart + (e.scaleEnd - e.scaleStart) * eased;
        const fadeIn = Math.min(1, progress * 7);
        const fadeOut = progress < 0.68 ? 1 : Math.max(0, (1 - progress) / 0.32);
        c.save();
        c.globalAlpha = e.alpha * fadeIn * fadeOut;
        c.translate(Math.round(e.x), Math.round(e.y));
        c.rotate(rot * e.facing);
        c.scale(e.facing * scale, scale);
        c.drawImage(DF.Assets.get('vfx_' + e.key), f * 128, 0, 128, 128, -64, -64, 128, 128);
        c.restore();
      }
    }
  }
  DF.Effects = Effects;
})();
