// Единый источник настроек. Всё глобальное живёт в одном пространстве имён window.DF.
(function () {
  const DF = (window.DF = window.DF || {});
  DF.CONFIG = {
    VIEW_W: 960, VIEW_H: 540, TILE: 32,
    STEP: 1 / 120,            // фиксированный шаг физики (сек)
    GRAVITY: 2200, MAX_FALL: 1100,
    PLAYER: {
      W: 24, H: 56, SPEED: 260, ACCEL: 2600, FRICTION: 3000, AIR: 0.75,
      JUMP: 760, JUMP_CUT: 0.45, COYOTE: 0.1, BUFFER: 0.12, DROP_TIME: 0.2,
      HP: 100, STAMINA: 100, STA_REGEN: 45, STA_DELAY: 0.8, INVULN: 0.7, ESTUS: 3, ESTUS_HEAL: 60
    },
    KEYS: {
      left: ['ArrowLeft', 'KeyA'], right: ['ArrowRight', 'KeyD'],
      down: ['ArrowDown', 'KeyS'], jump: ['Space', 'ArrowUp', 'KeyW'],
      light: ['KeyJ', 'KeyZ'], heavy: ['KeyK', 'KeyX'], special: ['KeyL', 'KeyV'],
      roll: ['ShiftLeft', 'ShiftRight', 'KeyC'], interact: ['KeyE'], heal: ['KeyQ'],
      debug: ['F3'], wipe: ['F9'],
      confirm: ['Enter'], cancel: ['Escape']
    },
    // Манифест ресурсов: { ключ: 'путь' }. Нет файла — рисуется заглушка.
    ASSETS: { player: 'assets/player/knight.png', sword_wood: 'assets/items/sword_wood.png', sword_steel: 'assets/items/sword_steel.png' },
    // Эффекты-росчерки: frames — число кадров листа 128×128, fps — скорость.
    VFX: { slash3_c4: { frames: 9, fps: 30 }, slash1_c4: { frames: 9, fps: 30 }, slash3_c5: { frames: 9, fps: 30 }, slash2_c5: { frames: 7, fps: 28 }, slash1_c5: { frames: 9, fps: 30 } },
    // NPC-листы (кадры 128×128, ноги на ay): торговец.
    NPC: { trader: { ax: 64, ay: 126, idle: { frames: 6, fps: 5 }, talk: { frames: 6, fps: 7 }, approve: { frames: 5, fps: 8 } } },
    // Статичный спрайт героя: facesRight — куда он смотрит на картинке; ногами стоит на нижней кромке файла.
    SPRITE: { facesRight: true, frame: 128, anchorX: 34, skin: 'knight1', skins: ['knight1', 'knight2', 'knight3'] },
    // Анимации спрайт-листов: file — имя PNG, frames — число кадров, fps — скорость, hit — кадр самого удара.
    ANIMS: {
      idle: { file: 'idle', frames: 4, fps: 6 }, walk: { file: 'walk', frames: 8, fps: 10 }, run: { file: 'run', frames: 7, fps: 13 },
      jump: { file: 'jump', frames: 6, fps: 10 }, hurt: { file: 'hurt', frames: 2, fps: 8 }, dead: { file: 'dead', frames: 6, fps: 8 },
      defend: { file: 'defend', frames: 5, fps: 10, hit: 2 }, protect: { file: 'protect', frames: 1, fps: 1 },
      attack1: { file: 'attack1', frames: 5, fps: 10, hit: 4 }, attack2: { file: 'attack2', frames: 4, fps: 10, hit: 2 },
      attack3: { file: 'attack3', frames: 4, fps: 10, hit: 2 }, runattack: { file: 'runattack', frames: 6, fps: 10, hit: 3 }
    }
  };
  // Манифест ресурсов: статичный запасной спрайт + все листы всех скинов (ключ «скин_анимация»).
  const K = DF.CONFIG;
  K.SPRITE.skins.forEach(skin => Object.entries(K.ANIMS).forEach(([k, a]) => { K.ASSETS[skin + '_' + k] = `assets/player/${skin}/${a.file}.png`; }));
  ['idle', 'walk', 'run', 'attack', 'hurt', 'dead', 'howl'].forEach(k => { K.ASSETS['werewolf_' + k] = `assets/enemies/werewolf/${k}.png`; });   // оборотень (пикселизован из HD-листа)
  K.ASSETS['dummy_idle'] = 'assets/enemies/dummy/idle.png';
  K.ASSETS['dummy_hurt'] = 'assets/enemies/dummy/hurt.png';
  K.ASSETS['dummy_dead'] = 'assets/enemies/dummy/dead.png';
  Object.keys(K.VFX).forEach(k => { K.ASSETS['vfx_' + k] = `assets/effects/${k}.png`; });
  Object.keys(K.NPC.trader).filter(k => k !== 'ax' && k !== 'ay').forEach(k => { K.ASSETS['trader_' + k] = `assets/npc/trader/${k}.png`; });
})();
