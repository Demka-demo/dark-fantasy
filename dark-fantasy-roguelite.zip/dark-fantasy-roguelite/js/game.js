// Единый цикл requestAnimationFrame: фиксированный шаг логики + отдельная отрисовка.
// Здесь же правила «как в Dark Souls»: костры, смерть, потерянные души, респавн врагов, сохранение.
(function () {
  const DF = window.DF, C = DF.CONFIG, T = C.TILE, PRESS = ['jump', 'light', 'heavy', 'special', 'roll', 'heal'];
  class Game {
    constructor(canvas) {
      this.input = new DF.Input(); this.renderer = new DF.Renderer(canvas); this.camera = new DF.Camera();
      this.world = DF.World.createTestRoom(); this.animator = new DF.Animator();
      const sv = DF.Save.load() || {};
      this.bonfireId = sv.bonfire || null; this.lit = new Set(sv.lit || []); this.souls = sv.souls || 0; this.bloodstain = sv.blood || null;
      const sp = this.spawnPoint(); this.player = new DF.Player(sp.x, sp.y);
      this.enemies = []; this.spawnEnemies();
      this.mode = 'play'; this.deadT = 0; this.fade = 1; this.banner = { text: '', t: 0 }; this.shake = 0; this.hitstop = 0; this.time = 0;
      this.fx = []; this.parts = []; this.queue = {};
      this.debug = false; this.fps = 0; this.acc = 0; this.last = 0; this._fpsT = 0; this._fpsN = 0;
      this.camera.snap(this.player, this.world);
      this.loop = t => {
        const dt = Math.min((t - this.last) / 1000, 0.1); this.last = t;
        this.update(dt); this.renderer.draw(this);
        this._fpsT += dt; this._fpsN++;
        if (this._fpsT >= 0.5) { this.fps = Math.round(this._fpsN / this._fpsT); this._fpsT = 0; this._fpsN = 0; }
        requestAnimationFrame(this.loop);
      };
    }
    start() { requestAnimationFrame(t => { this.last = t; this.loop(t); }); }
    spawnPoint() {
      const b = this.world.bonfires.find(x => x.id === this.bonfireId);
      return b ? { x: b.x - C.PLAYER.W / 2, y: b.y - C.PLAYER.H } : { x: this.world.spawn.x, y: this.world.spawn.y };
    }
    spawnEnemies() { this.enemies = this.world.spawns.map(s => new DF.Enemy(s.type, s.x, s.y)); }
    nearBonfire() {
      const p = this.player;
      return this.world.bonfires.find(b => Math.abs(p.x + p.w / 2 - b.x) < 40 && Math.abs(p.y + p.h - b.y) < 24) || null;
    }
    persist() { DF.Save.write({ bonfire: this.bonfireId, lit: [...this.lit], souls: this.souls, blood: this.bloodstain }); }
    say(text, t) { this.banner = { text, t: t || 2.2 }; }
    rest(b) {
      const first = !this.lit.has(b.id); this.lit.add(b.id); this.bonfireId = b.id;
      const p = this.player; p.hp = p.maxHp; p.sta = p.maxSta; p.estus = p.estusMax;
      this.spawnEnemies(); this.fade = 1; this.say(first ? 'КОСТЁР ЗАЖЖЁН' : b.name); this.persist();
    }
    addFx(x, y, text, color) { this.fx.push({ x, y, text, color, t: 1.0 }); }
    sparks(x, y, color, n) { for (let i = 0; i < n; i++) this.parts.push({ x, y, vx: (Math.random() - 0.5) * 260, vy: -Math.random() * 220, t: 0.35, color }); }
    onEnemyHit(e, def, dir, result) {
      this.addFx(e.x + e.w / 2, e.y - 10, String(def.damage), '#fff');
      this.sparks(e.x + e.w / 2, e.y + e.h / 2, '#ffd9a0', 6);
      this.hitstop = result === 'kill' ? 0.1 : 0.05; this.shake = Math.max(this.shake, def.kind === 'heavy' ? 7 : 3);
      if (result === 'kill') { this.souls += e.d.souls; this.addFx(e.x + e.w / 2, e.y - 28, `+${e.d.souls}`, '#e8d9a8'); this.persist(); }
    }
    onPlayerHit(e) {
      const p = this.player; this.sparks(p.x + p.w / 2, p.y + p.h / 2, '#c33', 8); this.hitstop = 0.07; this.shake = 8;
      this.addFx(p.x + p.w / 2, p.y - 10, String(e.d.dmg), '#ff6060');
    }
    die() {
      const p = this.player, pos = p.y > this.world.pxH ? p.safe : { x: p.x, y: p.y };
      if (this.souls > 0) this.bloodstain = { x: pos.x + p.w / 2, y: pos.y + p.h, souls: this.souls };   // новое пятно заменяет старое
      this.souls = 0; this.mode = 'dead'; this.deadT = 0; this.shake = 10; this.persist();
    }
    respawn() {
      const sp = this.spawnPoint(); this.player.reset(sp); this.animator = new DF.Animator();
      this.spawnEnemies(); this.mode = 'play'; this.fade = 1; this.camera.snap(this.player, this.world);
    }
    update(dt) {
      const i = this.input;
      if (i.pressed('debug')) this.debug = !this.debug;
      if (i.pressed('wipe')) { DF.Save.clear(); location.reload(); return; }
      for (const a of PRESS) if (i.pressed(a)) this.queue[a] = true;
      let sim = dt; if (this.hitstop > 0) { this.hitstop -= dt; sim = 0; }
      const cmd = { left: i.down('left'), right: i.down('right'), down: i.down('down'), jumpHeld: i.down('jump'), jumpPressed: false, press: {} };
      const idle = { press: {} }, p = this.player;
      for (this.acc += sim; this.acc >= C.STEP; this.acc -= C.STEP) {
        if (this.mode === 'play') {
          cmd.jumpPressed = !!this.queue.jump; cmd.press = this.queue; this.queue = {};
          p.update(C.STEP, cmd, this.world);
          for (const e of this.enemies) e.update(C.STEP, this.world, p);
          DF.Combat.update(this);
          if (p.hp <= 0) this.die();
        } else { this.queue = {}; p.update(C.STEP, idle, this.world); }
      }
      if (this.mode === 'play') {
        const nb = this.nearBonfire();
        if (i.pressed('interact') && nb && p.state === 'move' && p.onGround) this.rest(nb);
        const bs = this.bloodstain;
        if (bs && Math.abs(p.x + p.w / 2 - bs.x) < 28 && Math.abs(p.y + p.h - bs.y) < 40) {
          this.souls += bs.souls; this.addFx(bs.x, bs.y - 30, `+${bs.souls}`, '#e8d9a8'); this.bloodstain = null; this.persist(); this.say('ДУШИ ВОЗВРАЩЕНЫ', 1.8);
        }
        this.enemies = this.enemies.filter(e => !(e.dead && e.deadT > 1));
      } else { this.deadT += dt; if (this.deadT > 3.6) this.respawn(); }
      this.time += dt; this.fade = Math.max(0, this.fade - dt * 1.4); this.banner.t -= dt; this.shake = Math.max(0, this.shake - dt * 30);
      for (const f of this.fx) { f.y -= 28 * dt; f.t -= dt; } this.fx = this.fx.filter(f => f.t > 0);
      for (const q of this.parts) { q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 700 * dt; q.t -= dt; } this.parts = this.parts.filter(q => q.t > 0);
      this.animator.update(dt, p); this.camera.update(dt, p, this.world); i.endFrame();
    }
  }
  DF.Game = Game;
})();
