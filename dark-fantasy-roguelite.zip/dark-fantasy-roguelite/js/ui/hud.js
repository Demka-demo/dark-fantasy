// Интерфейс поверх игры: полосы, фляги, души, подсказки, баннеры, экран смерти.
(function () {
  const DF = window.DF, C = DF.CONFIG;
  const text = (c, s, x, y, size, color, align) => {
    c.font = `${size}px Georgia`; c.textAlign = align || 'left'; c.lineWidth = 3; c.strokeStyle = '#000'; c.strokeText(s, x, y); c.fillStyle = color; c.fillText(s, x, y);
  };
  DF.HUD = {
    draw(c, g) {
      const p = g.player, W = C.VIEW_W, H = C.VIEW_H;
      c.fillStyle = '#1a0c0e'; c.fillRect(16, 14, p.maxHp * 2.2 + 4, 16); c.fillStyle = '#b3262e'; c.fillRect(18, 16, p.hp * 2.2, 12);
      c.fillStyle = '#0d1a0d'; c.fillRect(16, 34, p.maxSta * 1.6 + 4, 10); c.fillStyle = '#4f9a4a'; c.fillRect(18, 36, p.sta * 1.6, 6);
      text(c, `Фляга (Q): ${p.estus}/${p.estusMax}`, 16, 62, 13, '#e0c27a');
      text(c, `Души  ${g.souls}`, W - 20, H - 20, 20, '#e8d9a8', 'right');
      const nb = g.nearBonfire();
      if (nb && g.mode === 'play') text(c, g.lit.has(nb.id) ? 'E — Отдохнуть у костра' : 'E — Зажечь костёр', W / 2, H - 70, 18, '#f3e2b0', 'center');
      if (g.banner.t > 0) { c.globalAlpha = Math.min(1, g.banner.t); text(c, g.banner.text, W / 2, H / 2 - 40, 34, '#e8c36a', 'center'); c.globalAlpha = 1; }
      if (g.mode === 'dead') {
        const a = Math.min(1, g.deadT / 1.2); c.globalAlpha = a;
        c.fillStyle = 'rgba(0,0,0,0.75)'; c.fillRect(0, H / 2 - 70, W, 140);
        text(c, 'ВЫ ПОГИБЛИ', W / 2, H / 2 + 18, 56, '#a31b1b', 'center'); c.globalAlpha = 1;
      }
      if (g.fade > 0) { c.fillStyle = `rgba(0,0,0,${Math.min(1, g.fade)})`; c.fillRect(0, 0, W, H); }
      c.textAlign = 'left';
    }
  };
})();
