// Тайловая карта. Типы: 0 — пусто, 1 — сплошной, 2 — односторонняя платформа.
(function () {
  const DF = window.DF, T = DF.CONFIG.TILE;
  class World {
    constructor(w, h) {
      this.w = w; this.h = h; this.pxW = w * T; this.pxH = h * T;
      this.grid = Array.from({ length: h }, () => new Array(w).fill(0));
      this.spawn = { x: 3 * T, y: 0 };
      this.zones = []; this.props = [];   // zones: [{x0,x1,theme}] в тайлах; props: декор {theme,c,r,tx,ty}
    }
    get(tx, ty) {
      if (tx < 0 || tx >= this.w || ty < 0) return 1;
      if (ty >= this.h) return 0;
      return this.grid[ty][tx];
    }
    themeAt(tx) { const z = this.zones.find(q => tx >= q.x0 && tx < q.x1); return z ? z.theme : 'castle'; }
    prop(theme, c, r, tx, ty) { this.props.push({ theme, c, r, tx, ty }); }
    rect(x, y, w, h, t) {
      for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++)
        if (i >= 0 && i < this.w && j >= 0 && j < this.h) this.grid[j][i] = t;
    }
  }
  World.createTestRoom = function () {
    const W = 100, H = 24, w = new World(W, H);
    w.rect(0, 0, W, 1, 1); w.rect(0, 0, 1, H, 1); w.rect(W - 1, 0, 1, H, 1); w.rect(0, H - 2, W, 2, 1);
    for (let i = 0; i < 6; i++) w.rect(10 + i, H - 3 - i, 1, i + 1, 1);   // лестница
    w.rect(20, H - 5, 6, 1, 2); w.rect(28, H - 8, 6, 1, 2);              // деревянные платформы
    w.rect(36, H - 11, 6, 1, 2); w.rect(44, H - 8, 5, 1, 2);
    w.rect(52, H - 4, 6, 2, 1); w.rect(58, H - 6, 5, 1, 1);              // каменные блоки
    w.rect(66, H - 4, 4, 2, 1);
    w.zones = [{ x0: 0, x1: 36, theme: 'castle' }, { x0: 36, x1: 58, theme: 'sewer' }, { x0: 58, x1: 77, theme: 'inferno' }, { x0: 77, x1: W, theme: 'castle' }];
    const F = H - 3;                                           // ряд декора, стоящего на полу
    [[5, 0, 7], [5, 1, 6], [4, 2, 17], [4, 3, 19], [4, 2, 21], [0, 6, 25], [1, 6, 26], [5, 3, 29], [7, 1, 33]].forEach(([c, r, tx]) => w.prop('castle', c, r, tx, F));
    [[6, 2, 14, 1], [6, 2, 14, 2], [7, 2, 27, 1], [7, 2, 27, 2], [6, 4, 1, 1], [7, 4, 34, 1]].forEach(([c, r, tx, ty]) => w.prop('castle', c, r, tx, ty));   // цепи и паутина под потолком
    [[4, 5, 40, H - 5], [5, 5, 48, H - 5], [6, 3, 44, 1], [7, 3, 55, 1]].forEach(([c, r, tx, ty]) => w.prop('sewer', c, r, tx, ty));                  // решётки стока и слизь
    [[7, 1, 63, F], [5, 1, 61, F], [7, 2, 70, 1], [7, 2, 70, 2]].forEach(([c, r, tx, ty]) => w.prop('inferno', c, r, tx, ty));
    [[5, 0, 79, F], [5, 3, 87, F], [1, 6, 94, F], [0, 6, 95, F], [4, 3, 97, F], [7, 4, 98, 1]].forEach(([c, r, tx, ty]) => w.prop('castle', c, r, tx, ty));
    const fy = (H - 2) * T;                                   // y поверхности пола
    w.spawn.y = fy - DF.CONFIG.PLAYER.H;
    w.bonfires = [{ id: 'ruins', name: 'Руины у входа', x: 4 * T + 16, y: fy }, { id: 'court', name: 'Разрушенный двор', x: 64 * T + 16, y: fy }, { id: 'haven', name: 'Тихая обитель', x: 82 * T + 16, y: fy }];
    w.safeX = 77 * T;                                          // туманные врата: враги дальше не проходят
    w.npcs = [{ type: 'trader', x: 90 * T, y: fy }];
    w.spawns = [['hollow', 18], ['wolf', 33], ['hollow', 40], ['wolf', 49], ['hollow', 60], ['brute', 71]]
      .map(([type, tx]) => ({ type, x: tx * T, y: fy }));
    return w;
  };
  DF.World = World;
})();
