// Единый источник характеристик атак, переката и врагов. Баланс правится только здесь.
(function () {
  const DF = window.DF;
  DF.DATA = {
    ATTACKS: {
      // kind — вид атаки; stagger сравнивается с poise врага: если не меньше — враг сбит с атаки.
      light: [   // лёгкое комбо из трёх ударов (J)
        { kind: 'light', stamina: 10, windup: 0.07, active: 0.09, recover: 0.16, damage: 16, anim: 'attack3', w: 50, h: 44, knock: 130, stagger: 10, lunge: 80 },
        { kind: 'light', stamina: 10, windup: 0.07, active: 0.09, recover: 0.16, damage: 18, anim: 'runattack', w: 50, h: 44, knock: 150, stagger: 10, lunge: 90 },
        { kind: 'light', stamina: 14, windup: 0.10, active: 0.11, recover: 0.30, damage: 26, anim: 'attack2', w: 58, h: 50, knock: 300, stagger: 25, lunge: 140 }
      ],
      heavy:   { kind: 'heavy',   stamina: 28, windup: 0.42, active: 0.12, recover: 0.42, damage: 48, anim: 'attack1', w: 64, h: 56, knock: 420, stagger: 45, lunge: 200 },  // K
      special: { kind: 'special', stamina: 22, windup: 0.12, active: 0.10, recover: 0.36, damage: 8, anim: 'defend',  w: 44, h: 50, knock: 560, stagger: 60, lunge: 60 }    // L: удар щитом
    },
    ROLL: { stamina: 18, time: 0.34, iframes: [0.04, 0.26], speed: 430 },
    ENEMIES: {
      hollow: { name: 'Полый воин', w: 24, h: 56, skin: 'knight2', scale: 1, hp: 60, speed: 60, chaseSpeed: 105, aggro: 230, range: 56, poise: 12, dmg: 18, windup: 0.55, active: 0.12, recover: 0.7, lunge: 60, hitW: 58, hitH: 52, knock: 240, souls: 40, color: '#7d6a58', eye: '#ff5a3c' },
      hound:  { name: 'Гончая', w: 34, h: 24, hp: 34, speed: 80, chaseSpeed: 190, aggro: 300, range: 95, poise: 6, dmg: 14, windup: 0.38, active: 0.22, recover: 0.8, lunge: 420, hitW: 40, hitH: 24, knock: 200, souls: 25, color: '#4a4e5c', eye: '#ffd23c' },
      brute:  { name: 'Палач', w: 34, h: 76, skin: 'knight3', scale: 1.25, hp: 180, speed: 40, chaseSpeed: 70, aggro: 200, range: 84, poise: 50, dmg: 42, windup: 0.85, active: 0.14, recover: 1.0, lunge: 40, hitW: 88, hitH: 70, knock: 520, souls: 150, color: '#5b3a3a', eye: '#ff2a2a' }
    }
  };
})();
