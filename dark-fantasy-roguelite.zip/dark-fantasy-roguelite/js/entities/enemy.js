// Один класс врага, поведение задаётся данными из DF.DATA.ENEMIES.
// Состояния: patrol → chase → windup (телеграф) → attack → recover; stagger при сбивании; dead.
(function () {
  const DF = window.DF, C = DF.CONFIG, T = C.TILE;
  class Enemy {
    constructor(type, cx, feetY) {
      const d = DF.DATA.ENEMIES[type];
      this.type = type; this.d = d; this.w = d.w; this.h = d.h; this.x = cx - d.w / 2; this.y = feetY - d.h;
      this.vx = 0; this.vy = 0; this.hp = d.hp; this.home = cx; this.dir = Math.random() < 0.5 ? -1 : 1; this.facing = this.dir;
      this.state = 'patrol'; this.t = 0; this.cd = 0; this.hurtFlash = 0; this.dead = false; this.deadT = 0; this.hitDone = false; this.onGround = false;
    }
    ahead(world, dy) { return world.get(Math.floor((this.x + (this.facing > 0 ? this.w + 3 : -3)) / T), Math.floor((this.y + dy) / T)); }
    blocked(world) { return this.ahead(world, this.h / 2) === 1 || (this.onGround && this.ahead(world, this.h + 4) === 0); }
    hurt(def, dir) {
      this.hp -= def.damage; this.hurtFlash = 0.12;
      if (this.hp <= 0) { this.dead = true; this.state = 'dead'; this.vx = dir * def.knock * 0.5; return 'kill'; }
      if (def.stagger >= this.d.poise) { this.state = 'stagger'; this.t = 0; this.vx = dir * def.knock; this.vy = -120; return 'stagger'; }
      this.vx += dir * def.knock * 0.2;
      if (this.state === 'patrol') this.state = 'chase';
      return 'hit';
    }
    update(dt, world, player) {
      const d = this.d; this.hurtFlash = Math.max(0, this.hurtFlash - dt); this.cd -= dt;
      this.vy = Math.min(this.vy + C.GRAVITY * dt, C.MAX_FALL);
      if (this.dead) { this.deadT += dt; this.vx *= 0.9; DF.Physics.move(this, world, dt); return; }
      const dx = player.x + player.w / 2 - (this.x + this.w / 2), dy = player.y + player.h / 2 - (this.y + this.h / 2), dist = Math.abs(dx);
      const alive = player.state !== 'dead', sees = alive && dist < d.aggro && Math.abs(dy) < 90;
      this.t += dt;
      if (this.state === 'patrol') {
        this.facing = this.dir; this.vx = this.dir * d.speed;
        if (this.blocked(world) || Math.abs(this.x - this.home) > 170) { this.dir = -this.dir; this.facing = this.dir; this.vx = this.dir * d.speed; this.home += (this.home - this.x) * 0; }
        if (sees) this.state = 'chase';
      } else if (this.state === 'chase') {
        if (!alive || dist > d.aggro * 1.6) this.state = 'patrol';
        this.facing = dx > 0 ? 1 : -1;
        if (dist > d.range * 0.8 && !this.blocked(world)) this.vx = this.facing * d.chaseSpeed; else this.vx = 0;
        if (alive && dist <= d.range && Math.abs(dy) < 60 && this.cd <= 0) { this.state = 'windup'; this.t = 0; this.vx = 0; }
      } else if (this.state === 'windup') {
        this.vx = 0; if (this.t >= d.windup) { this.state = 'attack'; this.t = 0; this.hitDone = false; this.vx = this.facing * d.lunge; }
      } else if (this.state === 'attack') {
        if (this.t >= d.active) { this.state = 'recover'; this.t = 0; }
      } else if (this.state === 'recover') {
        this.vx *= 0.88; if (this.t >= d.recover) { this.state = 'chase'; this.cd = 0.4; }
      } else if (this.state === 'stagger') {
        this.vx *= 0.92; if (this.t >= 0.45) { this.state = 'chase'; this.cd = 0.3; }
      }
      DF.Physics.move(this, world, dt);
    }
  }
  DF.Enemy = Enemy;
})();
