// Только отрисовка: читает состояние, ничего не меняет. Заглушки заменяются спрайтами через DF.Assets.
(function () {
  const DF = window.DF, C = DF.CONFIG, T = C.TILE;
  const hash = (a, b) => { let n = (a * 374761393 + b * 668265263) | 0; n = (n ^ (n >> 13)) * 1274126177 | 0; return ((n ^ (n >> 16)) >>> 0) / 4294967295; };
  class Renderer {
    constructor(canvas) {
      this.ctx = canvas.getContext('2d'); this.ctx.imageSmoothingEnabled = false;
      const g = this.ctx.createRadialGradient(C.VIEW_W / 2, C.VIEW_H / 2, C.VIEW_H * 0.4, C.VIEW_W / 2, C.VIEW_H / 2, C.VIEW_W * 0.65);
      g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.55)'); this.vignette = g;
    }
    background(cam) {
      const c = this.ctx, g = c.createLinearGradient(0, 0, 0, C.VIEW_H);
      g.addColorStop(0, '#0a0c14'); g.addColorStop(1, '#221a28');
      c.fillStyle = g; c.fillRect(0, 0, C.VIEW_W, C.VIEW_H);
      c.fillStyle = '#c9c4b0'; c.beginPath(); c.arc(760, 110, 30, 0, 7); c.fill();
      c.fillStyle = '#0a0c14'; c.beginPath(); c.arc(772, 102, 28, 0, 7); c.fill();
      this.towers(cam, 0.25, '#151824', 380, 7); this.towers(cam, 0.5, '#0f111a', 440, 13);
    }
    towers(cam, f, color, base, seed) {
      const c = this.ctx, sp = 170, off = cam.x * f, y0 = base - cam.y * f * 0.3;
      c.fillStyle = color;
      for (let i = -1; i <= C.VIEW_W / sp + 1; i++) {
        const idx = Math.floor(off / sp) + i, r = hash(idx, seed), x = idx * sp - off, w = 50 + r * 70, h = 90 + r * 150;
        c.fillRect(x, y0 - h, w, C.VIEW_H);
        for (let k = 0; k < w; k += 14) c.fillRect(x + k, y0 - h - 8, 8, 8);
        if (r > 0.6) { c.beginPath(); c.moveTo(x, y0 - h); c.lineTo(x + w / 2, y0 - h - 40); c.lineTo(x + w, y0 - h); c.fill(); }
      }
    }
    tiles(world, cam) {
      const c = this.ctx;
      const x0 = Math.max(0, Math.floor(cam.x / T)), x1 = Math.min(world.w - 1, Math.floor((cam.x + C.VIEW_W) / T));
      const y0 = Math.max(0, Math.floor(cam.y / T)), y1 = Math.min(world.h - 1, Math.floor((cam.y + C.VIEW_H) / T));
      for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
        const t = world.grid[ty][tx]; if (!t) continue;
        const x = tx * T, y = ty * T, sheet = DF.Assets.get('tiles_' + world.themeAt(tx));
        if (sheet) { this.tile(c, sheet, world, tx, ty, t, x, y); continue; }
        if (t === 1) {
          c.fillStyle = `hsl(225,9%,${20 + hash(tx, ty) * 8}%)`; c.fillRect(x, y, T, T);
          c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(x, y + T - 2, T, 2); c.fillRect(x + T - 2, y, 2, T);
          if (world.get(tx, ty - 1) !== 1) { c.fillStyle = '#4b5d49'; c.fillRect(x, y, T, 4); c.fillStyle = '#6f8568'; c.fillRect(x, y, T, 1); }
        } else {
          c.fillStyle = '#7a5636'; c.fillRect(x, y, T, 7);
          c.fillStyle = '#a07a50'; c.fillRect(x, y, T, 2);
          c.fillStyle = '#3d2a1a'; c.fillRect(x, y + 7, T, 1); c.fillRect(x + T / 2 - 1, y, 2, 7);
        }
      }
    }
    player(p, an, aura) {
      const c = this.ctx, pose = an.pose;
      if (an.sheet) {                                                                // анимация из спрайт-листа
        DF.Sprites.draw(c, Object.assign({ skin: C.SPRITE.skin, key: an.anim, frame: an.frame, x: p.x + p.w / 2, y: p.y + p.h, flip: p.facing > 0 ? 1 : -1, scale: 1, filter: aura || null }, pose)); return;
      }
      const img = DF.Assets.get('player');                                           // запасной вариант: статичный спрайт
      if (img) {
        const flip = (p.facing > 0) === C.SPRITE.facesRight ? 1 : -1, pv = pose.pivot * img.height;
        c.save(); c.globalAlpha = pose.alpha; c.translate(Math.round(p.x + p.w / 2), Math.round(p.y + p.h + pose.dy - pv));
        c.rotate(pose.rot); c.scale(pose.sx * flip, pose.sy); c.drawImage(img, -img.width / 2, -img.height + pv); c.restore(); return;
      }
      c.fillStyle = '#d8d2c0'; c.fillRect(Math.round(p.x), Math.round(p.y), p.w, p.h);
    }
    enemyOverlay(e) {                                                                // «!» перед ударом и полоска здоровья
      const c = this.ctx, d = e.d, x = Math.round(e.x), y = Math.round(e.y) - (d.h > 60 ? 10 : 0);
      if (e.state === 'windup') { c.fillStyle = '#ff7a30'; c.font = 'bold 20px Georgia'; c.fillText('!', x + e.w / 2 - 3, y - 12); }
      if (!e.dead && e.hp < d.hp) { c.fillStyle = '#200'; c.fillRect(x, y - 8, e.w, 4); c.fillStyle = '#c33'; c.fillRect(x, y - 8, e.w * e.hp / d.hp, 4); }
    }
    enemySprite(e, t) {                                                              // анимация врага из листов (таблица d.anims или общая ANIMS)
      const d = e.d, S = DF.Sprites; if (!d.skin || !S.has(d.skin)) return false;
      const A = d.anims || C.ANIMS, ak = d.atkAnim || 'attack1', sp = Math.abs(e.vx); let key = 'idle', fr = 0;
      if (e.dead) { key = 'dead'; fr = S.once(A.dead, e.deadT); }
      else if (e.state === 'windup') { key = ak; fr = S.attackFrame(A[ak], 'windup', e.t / d.windup); }
      else if (e.state === 'attack') { key = ak; fr = S.attackFrame(A[ak], 'active', 0); }
      else if (e.state === 'recover') { key = ak; fr = S.attackFrame(A[ak], 'recover', Math.min(1, e.t / d.recover)); }
      else if (e.state === 'stagger') { key = 'hurt'; fr = S.once(A.hurt, e.t); }
      else if (sp > 15) { key = sp > 150 && A.run ? 'run' : 'walk'; fr = S.loop(A[key], t); }
      else fr = S.loop(A.idle, t);
      S.draw(this.ctx, { skin: d.skin, key, frame: fr, x: e.x + e.w / 2, y: e.y + e.h, flip: e.facing, scale: d.scale || 1,
        ax: d.sheet && d.sheet.ax, ay: d.sheet && d.sheet.ay,
        alpha: e.dead ? Math.max(0, 1 - e.deadT / 0.9) : 1, filter: e.hurtFlash > 0 ? 'brightness(3)' : null });
      this.enemyOverlay(e);
      return true;
    }
    arc(cx, cy, r, facing, k, alpha, color, lw) {
      const c = this.ctx; c.save(); c.translate(cx, cy); c.scale(facing, 1);
      c.globalAlpha = alpha; c.strokeStyle = color; c.lineWidth = lw; c.lineCap = 'round';
      c.beginPath(); c.arc(0, 0, r, -1.3, -1.3 + 2.3 * k); c.stroke(); c.restore();
    }
    slashes(game) {
      const p = game.player, a = p.atk;
      if (!game.animator.sheet && !DF.Assets.get('vfx_slash3_c4') && p.state === 'attack' && (a.phase === 'active' || (a.phase === 'recover' && a.t < 0.08))) {
        const col = { light: '#e8e8f0', heavy: '#ffb060', special: '#7fb0ff' }[a.def.kind];
        const k = a.phase === 'active' ? a.t / a.def.active : 1, al = a.phase === 'active' ? 1 : 1 - a.t / 0.08;
        this.arc(p.x + p.w / 2, p.y + p.h * 0.45, p.w / 2 + a.def.w * 0.8, p.facing, k, al, col, a.def.kind === 'heavy' ? 7 : 3);
      }
      for (const e of game.enemies) if (e.state === 'attack' && !e.dead && !e.d.skin)
        this.arc(e.x + e.w / 2, e.y + e.h * 0.5, e.w / 2 + e.d.hitW * 0.8, e.facing, Math.min(1, e.t / e.d.active), 0.9, '#ff5a3c', 4);
    }
    enemy(e, t) {
      if (this.enemySprite(e, t)) return;
      const c = this.ctx, d = e.d, x = Math.round(e.x), y = Math.round(e.y), f = e.facing;
      c.globalAlpha = e.dead ? Math.max(0, 1 - e.deadT / 0.9) : 1;
      c.fillStyle = e.hurtFlash > 0 ? '#fff' : d.color;
      let eyeX, eyeY;
      {
        const bw = e.type === 'brute' ? 8 : 0;
        c.fillRect(x - bw / 2, y + 12, e.w + bw, e.h - 12); c.fillRect(x + e.w / 2 - 7, y, 14, 14);
        c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(x - bw / 2, y + e.h * 0.55, e.w + bw, 4);
        eyeX = x + e.w / 2 + (f > 0 ? 1 : -4); eyeY = y + 4;
        let ang = 0.9;                                                                 // оружие: поднимается в замахе, рубит в атаке
        if (e.state === 'windup') ang = 0.9 - 2.3 * (e.t / d.windup); else if (e.state === 'attack') ang = -1.4 + 2.3 * Math.min(1, e.t / d.active);
        const sx = x + e.w / 2 + f * e.w * 0.3, sy = y + e.h * 0.4, L = d.hitW * 0.75;
        c.strokeStyle = e.hurtFlash > 0 ? '#fff' : '#9aa0aa'; c.lineWidth = e.type === 'brute' ? 6 : 3;
        c.beginPath(); c.moveTo(sx, sy); c.lineTo(sx + f * Math.cos(ang) * L, sy + Math.sin(ang) * L); c.stroke();
      }
      c.fillStyle = d.eye; c.fillRect(eyeX, eyeY, 4, 3);
      if (e.state === 'windup') {                                                      // телеграф атаки
        c.strokeStyle = '#ff7a30'; c.lineWidth = 2; c.strokeRect(x - 2, y - 2, e.w + 4, e.h + 4);
        c.fillStyle = '#ff7a30'; c.font = 'bold 18px Georgia'; c.fillText('!', x + e.w / 2 - 3, y - 8);
      }
      if (!e.dead && e.hp < d.hp) { c.fillStyle = '#200'; c.fillRect(x, y - 8, e.w, 4); c.fillStyle = '#c33'; c.fillRect(x, y - 8, e.w * e.hp / d.hp, 4); }
      c.globalAlpha = 1;
    }
    bonfire(b, lit, t) {
      const c = this.ctx, x = b.x, y = b.y;
      c.fillStyle = '#2a2320'; c.fillRect(x - 14, y - 5, 28, 5); c.fillStyle = '#3a2f2a'; c.fillRect(x - 10, y - 9, 20, 4);
      c.fillStyle = '#9aa0aa'; c.fillRect(x - 1, y - 36, 3, 28); c.fillStyle = '#6b5a3a'; c.fillRect(x - 6, y - 20, 13, 3);
      if (!lit) { c.fillStyle = '#5a4a3a'; c.fillRect(x - 3, y - 11, 6, 3); return; }
      const f = Math.sin(t * 9 + x) * 2;
      c.fillStyle = '#ff6a1a'; c.beginPath(); c.moveTo(x - 10, y - 8); c.quadraticCurveTo(x - 8 + f, y - 30, x, y - 44 + f); c.quadraticCurveTo(x + 9 - f, y - 28, x + 10, y - 8); c.fill();
      c.fillStyle = '#ffd35a'; c.beginPath(); c.moveTo(x - 5, y - 8); c.quadraticCurveTo(x - 3, y - 20, x, y - 28 - f); c.quadraticCurveTo(x + 4, y - 18, x + 5, y - 8); c.fill();
      const g = c.createRadialGradient(x, y - 20, 4, x, y - 20, 150); g.addColorStop(0, 'rgba(255,140,40,0.35)'); g.addColorStop(1, 'rgba(255,140,40,0)');
      c.globalCompositeOperation = 'lighter'; c.fillStyle = g; c.fillRect(x - 150, y - 170, 300, 300); c.globalCompositeOperation = 'source-over';
    }
    blood(b, t) {
      const c = this.ctx, a = 0.6 + Math.sin(t * 3) * 0.2;
      c.fillStyle = `rgba(130,12,18,${a})`; c.beginPath(); c.ellipse(b.x, b.y - 3, 16, 5, 0, 0, 7); c.fill();
      c.fillStyle = `rgba(255,220,150,${a})`; c.fillRect(b.x - 2, b.y - 22 - Math.sin(t * 3) * 3, 4, 8);
    }
    // Автотайлинг из тайлсета: край выбирается по тому, с каких сторон тайл открыт (рамка 3×3 в ячейках 0..2).
    tile(c, sheet, world, tx, ty, t, x, y) {
      const S = 32, h = hash(tx, ty), cfg = C.TILESETS[world.themeAt(tx)], solid = (a, b) => b >= world.h || world.get(a, b) === 1;
      let col, row;
      if (t === 2) { const l = world.get(tx - 1, ty) !== 2, r = world.get(tx + 1, ty) !== 2; col = l && !r ? 3 : r && !l ? 5 : 4; row = 4; }
      else {
        const top = !solid(tx, ty - 1), left = !solid(tx - 1, ty), right = !solid(tx + 1, ty), bottom = !solid(tx, ty + 1);
        if (top && left) { col = 0; row = 0; } else if (top && right) { col = 2; row = 0; } else if (top) { col = 1; row = h < 0.35 ? 5 : 0; }
        else if (bottom && left) { col = 0; row = 2; } else if (bottom && right) { col = 2; row = 2; } else if (bottom) { col = 1; row = 2; }
        else if (left) { col = 0; row = 1; } else if (right) { col = 2; row = 1; }
        else { const f = cfg.fill[Math.floor(h * cfg.fill.length)]; col = f[0]; row = f[1]; }
      }
      c.drawImage(sheet, col * S, row * S, S, S, x, y, S, S);
    }
    props(world, cam) {                                                              // декор: бочки, ящики, цепи, паутина...
      const c = this.ctx;
      for (const p of world.props) {
        const sheet = DF.Assets.get('tiles_' + p.theme), x = p.tx * T, y = p.ty * T;
        if (!sheet || x + T < cam.x || x > cam.x + C.VIEW_W) continue;
        c.drawImage(sheet, p.c * 32, p.r * 32, 32, 32, x, y, 32, 32);
      }
    }
    gate(world, t) {                                                                 // туманные врата безопасной зоны
      if (!world.safeX) return;
      const c = this.ctx, x = world.safeX, y1 = (world.h - 2) * T, y0 = y1 - 220, a = 0.28 + Math.sin(t * 2) * 0.08;
      const g = c.createLinearGradient(x - 22, 0, x + 22, 0); g.addColorStop(0, 'rgba(190,210,255,0)'); g.addColorStop(0.5, `rgba(190,210,255,${a})`); g.addColorStop(1, 'rgba(190,210,255,0)');
      c.fillStyle = g; c.fillRect(x - 22, y0, 44, y1 - y0);
    }
    npc(n, game) {
      const c = this.ctx, S = DF.Sprites, tr = game.trader, cfg = C.NPC.trader, p = game.player;
      if (!S.has('trader')) { c.fillStyle = '#4a3d6a'; c.fillRect(n.x - 12, n.y - 52, 24, 52); return; }
      let key = 'idle', fr;
      if (game.mode === 'shop') { key = 'talk'; fr = S.loop(cfg.talk, tr.t); }
      else if (tr.approveT > 0) { key = 'approve'; fr = S.once(cfg.approve, 1.2 - tr.approveT); }
      else fr = S.loop(cfg.idle, tr.t);
      S.draw(c, { skin: 'trader', key, frame: fr, x: n.x, y: n.y, flip: p.x + p.w / 2 < n.x ? -1 : 1, scale: 1, ax: cfg.ax, ay: cfg.ay });
    }
    draw(game) {
      const c = this.ctx, cam = game.camera, sh = game.shake;
      const cx = Math.round(cam.x + (Math.random() - 0.5) * sh), cy = Math.round(cam.y + (Math.random() - 0.5) * sh);
      this.background({ x: cx, y: cy });
      c.save(); c.translate(-cx, -cy);
      this.tiles(game.world, { x: cx, y: cy }); this.props(game.world, { x: cx, y: cy }); this.gate(game.world, game.time);
      for (const b of game.world.bonfires) this.bonfire(b, game.lit.has(b.id), game.time);
      if (game.bloodstain) this.blood(game.bloodstain, game.time);
      for (const n of game.world.npcs) this.npc(n, game);
      for (const e of game.enemies) this.enemy(e, game.time);
      this.player(game.player, game.animator, game.player.state === 'attack' ? DF.DATA.WEAPONS[game.weapon].fx.aura : null); this.slashes(game); game.vfx.draw(c);
      for (const q of game.parts) {
        const sz = q.size || 3, al = Math.min(1, q.t / 0.2); c.fillStyle = q.color;
        if (q.glow) { c.globalCompositeOperation = 'lighter'; c.globalAlpha = al * 0.35; c.fillRect(Math.round(q.x) - 2, Math.round(q.y) - 2, sz + 4, sz + 4); }
        c.globalAlpha = al; c.fillRect(Math.round(q.x), Math.round(q.y), sz, sz); c.globalCompositeOperation = 'source-over';
      }
      c.globalAlpha = 1; c.font = 'bold 14px Georgia'; c.textAlign = 'center';
      for (const f of game.fx) { c.globalAlpha = Math.min(1, f.t * 2); c.lineWidth = 3; c.strokeStyle = '#000'; c.strokeText(f.text, f.x, f.y); c.fillStyle = f.color; c.fillText(f.text, f.x, f.y); }
      c.globalAlpha = 1; c.textAlign = 'left';
      if (game.debug) {
        const p = game.player; c.lineWidth = 1; c.strokeStyle = '#0f0'; c.strokeRect(Math.round(p.x) + 0.5, Math.round(p.y) + 0.5, p.w, p.h);
        c.strokeStyle = '#f33'; const B = DF.Combat.box;
        if (p.state === 'attack' && p.atk.phase === 'active') { const b = B(p, p.atk.def.w, p.atk.def.h); c.strokeRect(b.x, b.y, b.w, b.h); }
        for (const e of game.enemies) { c.strokeRect(e.x, e.y, e.w, e.h); if (e.state === 'attack') { const b = B(e, e.d.hitW, e.d.hitH); c.strokeRect(b.x, b.y, b.w, b.h); } }
      }
      c.restore();
      c.fillStyle = this.vignette; c.fillRect(0, 0, C.VIEW_W, C.VIEW_H);
      DF.HUD.draw(c, game);
      if (game.debug) {
        const p = game.player; c.fillStyle = '#e8e8e8'; c.font = '12px monospace';
        [`FPS ${game.fps}`, `pos ${p.x.toFixed(0)}, ${p.y.toFixed(0)}`, `state ${p.state}`, `enemies ${game.enemies.filter(e => !e.dead).length}`].forEach((t, i) => c.fillText(t, 10, 80 + i * 15));
      }
    }
  }
  DF.Renderer = Renderer;
})();
